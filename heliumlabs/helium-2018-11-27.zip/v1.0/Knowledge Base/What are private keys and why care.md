---
title: "What are private keys and why care"
excerpt: ""
---
gjhiggins wrote:

>'While your SPR are on Bittrex, as far as the blockchain is concerned, they *belong* to Bittrex. “Depositing” coins on Bittrex === sending them to a Bittrex-controlled address.

>It's one of the basics: no ticket, no ride, i.e. no privkey, no coins.

>Bittrex have the privkey of your Bittrex address, so *they* will get the amount of Helium issued against that privkey and its UTXO balance and *they* will pass them on to you. That's the general idea - so that people who have significant amounts of SPR parked on Bittrex won't miss out on the Helium distro. But it doesn't change the fact that while your coins are on Bittrex, they are owned^Wcontrolled by Bittrex and if Bittrex ultimately decline to be involved in the distro, they have no obligation to do anything with the privkeys they hold to SPR addresses.

>If you want the Helium to arrive under *your* control, withdraw your SPR from Bittrex to your own wallet and when the tx is adequately confirmed for your peace of mind, simply shut down your SPR wallet. Y'see it's not so much that transactions are recorded on the blockchain, they are *implemented* on the blockchain. As long as you have your privkey safely written down somewhere, you don't even need a computer to store your coins. They'll be waiting for you on the blockchain, whenever you're ready.

>It's worth doing, as a safety drill. I'm not sure if there's a Spreadcoin testnet or not but if there is, use that for preference. Or run the drill on the testnet of another altcoin, it's a standard safety drill.

>1. Start your client and use the console to “dumpprivkey <address>” for each of your addresses with a non-zero balance (or consolidate them into one address, according to your infosec preferences). Copy the privkeys somewhere safe, (actually, while you're at it, [b]write down each privkey[/b]).

>2. Shut down the client.

>3. Navigate to wherever you have configured the “datadir” data directory to be --- or to the platform-specific default, e.g. as detailed in GetDefaultDataDir: https://github.com/spreadcoin/spreadcoin/blob/master/src/util.cpp#L1031 

>4. MOVE “wallet.dat” file somewhere else on your computer, just for convenience. (If you're feeling super-confident, you could just delete it but why not try that *next* time through?).

>4a. See other OPTIONS (below) at this point, assuming that you *have* written down your privkey(s)

>5. Start the client.

>6. Note the 0 balance. Don't despair.

>7. Using the console, enter “importprivkey <privkey>”, feeding it your privkeys as you go.

>8. Check the overview tab, as you import each privkey, the address appears in the wallet and all the tx show up in the tx history.

>9. Shut down the client, navigate to “datadir” and DELETE “wallet.dat”. MOVE the original “wallet.dat” file back into “datadir”. (This step is basically theatre, if you've successfully imported all your privkeys, you could just use the new wallet and discard the old one)

>10. Start the client, check the tx history and balance, all should be exactly as before.

>OPTIONS: Book a hermit's holiday - 6 months on top of a convenient mountain-top. Before you depart, put your computer in a blender, client, wallet and all (but *NOT* the paper on which you have written the privkeys), switch it on. Dispose of the trash responsibly. Enjoy your holiday. On your return, buy a replacement computer, d/l a copy of the client, start it up, import your privkeys and you should be back where you started, looking at your original balance and tx history.

>(Next in this series, how to do the Jason Bourne thing and have a privkey laser projector embedded in your flesh.)

>CLAMs were distributed by snapshot (of three blockchains, BTC, LTC and DOGE). If you had an address or addresses with non-dust amounts on any of the three chains, you got 4-and-a-bit CLAMs for each addy. I had a couple of DOGE addresses and Ngaio had two, so we got 16-and-a-bit CLAMs in total. Collecting them was interesting. You moved your DOGE wallet aside, started the client to create a new empty DOGE wallet, made a note of the new address, shut down the client, move the new wallet to one side, bringing back the old wallet. Start the client again, send all your DOGE to the new address, wait for confirmation. After confirmation, move the old wallet (with old addrs now with 0 balance) somewhere handy and move the new wallet back into place as the DOGE wallet (one new addy, with all yr DOGE). You were now done with that stage.

>Next stage, start CLAMs client, click Import->Wallet, select old (empty) DOGE wallet and as if by magic (but actually by privkey), there's a 4-and-a-bit CLAMs balance for every (qualifying, i.e. non-dust) was-DOGE-now-CLAMs address. Delete old empty DOGE wallet.

>CLAMs is doing okay at just short of $8 a pop. It's a PoS coin and the 16-and-a-bit CLAMs we started with has grown to 100+. All because I knew: no ticket, no ride.'

Wrap • Sep 23rd at 2:37 PM