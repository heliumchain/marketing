---
title: "Introducing Helium Masternodes"
excerpt: ""
---
## What is a Masternode?

A Masternode is a server that provides services to the Helium network. A Masternode hosts a copy of the blockchain (just like a Bitcoin node) and helps to secure the network.

Masternodes also enable the network's more advanced features, such as[ Instant Send](http://google.com), [Private Send](http://google.com), [Coin Mixing](http://google.com) and [Decentralised Governance](http://google.com).

Because of the important job they are doing, Masternodes are rewarded by the network. Of every block reward, 45% goes to miners, 45% goes to Masternodes and 10% goes to [budget proposals.](http://google.com)

Masternodes also get to vote on how the budget is spent, as well as on important decisions that impact the network.

## Why would I want to run a Masternode?

There are several reasons why you would want to run a Masternode.

* The more Masternodes the Helium network has the more distributed and stronger it becomes. So if you happen to own some Helium, why not use it for a Masternode and put your investment to work.

* There is a financial reward. Running a full bitcoin node requires an investment in time, hardware, power and bandwidth but, for the average user, doesn't have a benefit. Running a Helium Masternode entitles you to 45% of mining rewards. As a rule of thumb this is more than enough to cover the costs of the server and the opportunity costs of parking your capital.

* Masternodes have voting rights. You will get to decide where the development budget goes, you will get to decide on critical development decisions and if you don't like where the project is heading, you'll get to fire the Development Team.

* Masternodes are fun and fashionable. You can keep your coins in a paper wallet and stare at coinmarketcap all day or you use them for a Masternode: Crypto's answer to the Tamagotchi.

## How does a Masternode work?

A Helium Masternode essentially consists of two parts: a wallet that holds 1000 HLM collateral and a server which does all the work.

The reason for the collateral is two-fold. A 1000 HLM collateral means that as the network grows and attacks become more likely, attacks become more and more expensive as well. The collateral also ensures that [decision power lies with the people who have most at stake](https://plato.stanford.edu/entries/voting/#6.1). 

The other part of the system is the actual Masternode server. This is a remotely hosted server that takes care of everything. It is either hosted on a VPS by yourself or by a dedicated Masternode hosting provider that takes care of all the administrative aspects for you.

The two parts of the system communicate with each other by means of a Masternode Key. This way the Masternode knows where the collateral is and where to send the payments while the collateral can be kept safe on an offline machine. You will generate the Masternode Key from the wallet where you keep the collateral.

Since the Masternode needs to be online 24/7 but the wallet doesn't, remotely hosting the Masternode is a lot cheaper and safer than hosting it on your own computer. If someone were to hack into your VPS the worst thing they can do is break it. Your collateral will be safe.

## How do I set it up?

The choice is yours really. Some people like the challenge of hosting a Masternode themselves. They rent a VPS with a cloud provider such as Vultr, Amazon or Digital Ocean and install and maintain everything themselves. We have guides on how to do that here:

LINK TBA

Others prefer some more convenience. [Nodeshare.in](http://nodeshare.in), [Node-vps](http://www.node-vps.com) and [MP Hosting](https://mp-hosting.co.uk/cart.php?gid=12) will offer dedicated Masternode hosting. This means they will install all the software, set everything up and make sure everything is working. They'll charge you a small fee for their service however. The aforementioned providers have been around for quite some time now and have an outstanding reputation in the community.

Both options are equally safe.

Once everything has been taken care of; put the champagne in the cooler and wait for the first Masternode payment to pop up in your wallet.