---
title: "Wallet troubleshooter (FAQ)"
excerpt: ""
---
**With big thanks to Moonshot (Phore) and Pivx.org. Adapted for Helium**

This FAQ addresses common issues and solutions when troubleshooting the Helium wallet. .


#Q1. My wallet appears to be stuck syncing the blockchain and remains at X hours left. It’s been many hours and the status hasn’t changed. How can I fix this?

Connecting to some bad peers or your chain becoming corrupted somehow can cause blockchain syncing to stall.

First, try shutting down and restarting the wallet, and after it’s synced up, check if you are on the right blockchain as per Q6 in this FAQ. If you are on the right chain but it still isn’t syncing the newer blocks, please follow solution steps outlined in Q2 below to resync cleanly off the network with a new peers.dat. Also, ensure that your **helium.conf** doesn’t have any <code>connect=</code> or <code>addnodes=</code> lines, unless you know why they are there and you put them in there for a good reason. To check **helium.conf**, look in the folders listed below in Q3.

#Q2. My wallet crashes often or has crashed and now it won’t launch. How do I fix this?

An abnormal exit of the wallet could result in a blockchain inconsistency from that point onwards. This can happen due to a PC crash or reboot without first fully closing the wallet, or if the downloaded blockchain somehow got corrupted and caused the wallet to crash.

If users experience wallet launch failures, try using the <code>-forcestart</code> startup flag 

On Windows systems, you need to edit the shortcut and append it at the end) which will bypass the new procedures altogether, and in rare cases allow the wallet to run.

On Mac: Launch **Terminal** and enter this command; <code>/Applications/Helium-qt.app -forcestart</code>

On Linux: Launch **Terminal**, change directories to the folder that has **helium-qt** and enter this command: <code>./helium-qt -forcestart</code>

If the wallet startup issue is not fixed with the <code>-forcestart</code> flag, you should resync the blockchain by deleting the blockchain data in your data folder.
Since you will not delete your **.conf** files and **wallet.dat** file, this will not affect your coins or your masternodes.

Delete everything **EXCEPT** your **helium.conf**, **masternode.conf** and **wallet.dat** files, and the **backups** folder. (default folder locations are listed under Question 3 below)
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/7bbe8d2-datadir.png",
        "datadir.png",
        480,
        700,
        "#f8e9e9"
      ]
    }
  ]
}
[/block]
Now re-launch the wallet. Wait for it to sync. This can take few hours on slower internet connections.

Also, it is recommended that after a successful full resync, make a backup of your good blockchain as this “good” blockchain snapshot could come handy later and means you’ll be able to avoid a full resync if your chain gets corrupt again. To make a backup of the good blockchain, follow the steps outlined in Q5 below. If you face a corrupt blockchain again, just delete the 2 folders chainstate & blocks only, copy over the good backup blocks & chainstate folders, then restart the wallet.

#Q3. Where are my wallet.dat, blockchain and conf files located?

Unless you changed the default location when you installed the Helium wallet, they are located in the following locations for each OS type:

Windows
Go to Start > Run > <code>%APPDATA%\Helium</code>
(or just enter the above path in explorer)

OSX
<code>~/Library/Application Support/Helium</code>
(/Users/“username”/Library/Application Support/Helium)

Linux
<code>~/.helium</code>

#Q4. Are there Helium blockchain snapshots that I can download so that I don’t need to sync the blockchain over the network?

Helium does not currently provide any official snapshots. We recommend that everyone sync their wallet initially over the network to help ensure that it is 100% accurate and has not been tampered with. If you want to, you can then make your own blockchain snapshot for future use any time you want (see below).

#Q5. How do I make a backup of the blockchain so I can avoid a full resync if something goes wrong?

As the Helium blockchain grows, it will take an increasingly longer time to sync the blockchain from the beginning. While we feel it is important to do this initially to obtain a trustworthy copy of the correct Helium blockchain, you can avoid having to do full resync by making your own Helium blockchain snapshot.

After a successful full blockchain sync, and if your wallet it working fine, you can make a snapshot of the good blockchain using these steps:

-Close your wallet gracefully (**File** -> **Exit** or <code>helium-cli stop</code>)
-Go to your blockchain data directory. (default directories listed above in Q3 above)
-Copy the 2 folders (blocks & chainstate) elsewhere (another directory or USB / hard drive),  Start the wallet again and continue using the Helium wallet.

If you have an issue in the future from a corrupt blockchain (as in Question 1 above), you can now:

-Close the wallet
-Delete the blocks and chainstate folders
-Copy the good snapshot of the blocks & chainstate folders to the Helium data directory and start the wallet

If your snapshot was done properly, it will start syncing from the time you took your snapshot.

#Q6. My staking or Masternode reward is a different amount / more frequent than expected, and/or my recent transactions aren’t showing up in block explorer but my wallet is fully synced and seems up to date. How can I fix this?

There is a possibility that your wallet may be not synced up with the network properly, or that your wallet may have somehow started syncing an incorrect blockchain fork and isn’t connected to the main Helium blockchain network. 

To make sure that you are on the right block and is on the right network, [please follow the steps outlined here.](https://www.heliumlabs.org/v1.0/docs/how-to-check-if-my-wallet-is-in-the-correct-chain)

If you see lots of conflicted transactions (which are not valid transactions), follow the steps below in Q7 to clear them.

#Q7. I see a lot of conflicted / orphan transactions as a result of staking but not winning those blocks. Is there a way to clean them up and not show them?

Yes, there is a simple way and for a wallet that is properly synced to the correct Helium blockchain, it doesn’t affect your balance since the orphaned rewards are not valid rewards and are already not included in your balance:

-Backup your wallet if you haven’t done so recently (this is just a precaution and not mandatory).
-Go to **Tools** -> **Wallet Repair**
-Press the button for** Recover Transactions 1** (zapwallettxes=1)

It will now go through your wallet and within a few minutes it will find and remove the orphan transactions.