---
title: "FAQ - DISCONTINUED"
excerpt: ""
---
**This FAQ has been discontinued: [this is the new one](https://www.heliumlabs.org/v1.0/docs/frequently-asked-questions)**

**TL;DR HLM will launch soon. Until then: wait. Yes, its taking a long time. No you haven't been scammed. Yes things take REALLY long but no you haven't been scammed**

R.I.P.: Mar 22st 00:26 GMT

Join the [slack](https://heliumslack.herokuapp.com/) to stay updated.

Join the [mailing list](https://goo.gl/forms/8flzE0N8mYppcKDE3) to stay updated.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/8a4800f-karma.png",
        "karma.png",
        516,
        145,
        "#efeeee"
      ]
    }
  ]
}
[/block]
Anyone is more than welcome to make an account and suggest edits to this page.

*As Slack only keeps the last 10k messages @Rzerod was kind enough to make the entire Slack history accessible for purpose of transparency. It can be found here: [https://helium-archive.neocities.org/](https://helium-archive.neocities.org/) Warning: long loading time.

# Slack security notices

1. The Slack is open for everyone and will undoubtedly attract **scammers** as well. **Be aware** of this.

2. Be careful to not click any **phishing links** sent through email or direct message. Known scams include fraudulent links to **myetherwallet.com**, **neotracker.io** and **blockchain.info**.

3. Around launch there will be a great many people in need of technical support and some people will want to take advantage. If someone asks you to `dumpprivkey` or do some other weird stuff: **DON'T DO IT** and  **contact a moderator**. Slack moderators are: @craslovell, @RzeroD @teela,  @kristerv, @rhinomonkey, @radical_edward, @first last, @karmashark and  @coins101. 


#Safety awareness

1. Never browse without add blockers. [Ublock Origin](https://en.wikipedia.org/wiki/UBlock_Origin) and [Disconnect](https://disconnect.me/) are a star team. Block Javascript. Different solutions will do also but just make sure you block it **all**.

2. Never click links. Only use bookmarks or type in the URL yourself. [Don't be spoofed.](http://www.businessinsider.com/scammers-spoofing-cryptocurrency-exchange-site-urls-incredibly-hard-to-spot-2018-2#usually-you-can-tell-if-a-website-isnt-legitimate-if-it-doesnt-have-the-green-https-that-comes-before-a-websites-url-1)

3. Separate your accounts. Use one email address for exchanges. Use a different one for forums, airdrops etc. Keep your personal email personal. ([protonmail is awesome](https://protonmail.com/))

4. Make back ups of everything, and back up your back ups. Hardware wallets rock. [Encrypted USBs also do the trick](https://technet.microsoft.com/en-us/library/ff404223.aspx).

5. Turn on 2FA for all important accounts. Back up the codes.

6. Never use your (android) smartphone for anything crypto related other than 2FA.

7. Never download wallet files from anywhere other than official sources like the website, github or the OP on Bitcointalk.

8. **Be vigilant**.

# Snapshot

## When was the snapshot?

[Block number 1657200 at 8:12 PM UTC, 9th of October 2017.](https://chainz.cryptoid.info/spr/block.dws?80f6c62be9910cd3e245d071c8d3cc874bd035800411ddd506c13183370f612b.htm)

[This is the preliminary address-balance list of the snapshot.](https://gist.github.com/gjhiggins/863cdf66e8c003f15c17038ffaf12007)

The word 'preliminary' refers to the list, not the snapshot block. Block 1657200 is canonical. Just getting the information out is a bit tricky.

gjhiggins wrote:

>From a hardnosed pespective, Mr Spread hacked around with the codebase and then fucked off. We're left with trying to understand _all_ the consequences, at the C++ level no less. Fortunately, the blockchain is canonical, all we have to do is _read_ it (with tools we are obliged to create for ourselves). 

Accounts on Cryptopia have already been credited with a balance in Helium.


## I had my coins in a local wallet during the snapshot block, what will happen now?

Your balance has been recorded on the block that will be used for the distribution of Helium. You can keep your SPR in your wallet or move them out. The Helium team will provide you with detailed instructions on how to claim your coins at a later date. Also check out [Coins101's more detailed explanation](https://hackmd.io/s/B1Gt73I2-) 

## I've been living under a rock for the last months and kept my SPR on Bittrex, what now?

Bittrex was approached for the snapshot but decided not to participate. They may or may not be persuaded to credit Helium to SPR holders but it is entirely up to them ([no ticket no ride](https://www.heliumlabs.org/docs/what-is-a-private-key-and-why-should-i-care)).

coins101 wrote:

>However, we have made Bittrex aware of the snapshot block height. We have also offered to provide them with support for any coins left on the exchange at the cut off block height because people were away, sick, etc. You will need to open a support request directly with Bittrex and ask them to send us an email, detailing the number of coins they want and your exchange address.

So basically the best thing to do is raise a ticket,keep an eye on it, wait, and see how things play out. Please **don't** bother the devs with it.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/fb852a5-trexcoins.png",
        "trexcoins.png",
        1060,
        98,
        "#cbc4c4"
      ]
    }
  ]
}
[/block]
## Is my Spreadcoin useless now?

Spreadcoin is a pretty fun coin and there are lots of cool things you can do with it. The Helium and Spreadcoin devs decided to part ways and each coin will be headed a different direction. For some more info on where SPR is going check their [bitcointalk topic](https://bitcointalk.org/index.php?topic=715435.0), [forums](http://spreadcointalk.org/) and [website](http://www.spreadcoin.info/).

#Helium


## When will Helium launch?

The snapshot was a very big step, and the launch will be an even bigger one. The devs have mentioned 'several weeks' as a target timeline but there is a lot of work that still needs to be done so best be patient.

Coins101 wrote:

>We will not be providing details of the Helium launch as it poses a security risk. We'll likely give you a few hours notice when the network is ready for public release.

gjhiggins wrote:

>The consensus chain is the one adjudged to have required the most work. The shorter the chain, the easier it is to attack because it's comparatively easier to fake the amount of work done to attack the chain. A few days would give an esrtwhile attacker enough notice to prepare a competing chain - and replace the agreed opening ledger with one that may perhaps be a little more controversial.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/6ab7b5b-state_of_the_union.jpg",
        "state_of_the_union.jpg",
        1600,
        854,
        "#d4c6b0"
      ]
    }
  ]
}
[/block]
## When will the wallets be released?

karmashark wrote:

>Right now it is not possible to give a definitive time frame as there will be much work to do once the snapshot takes place for us behind the scenes. @coins101 answered 'much longer' and I would echo that sentiment. Weeks likely however this is just an estimate

>We have been and continue to work away on the wallet(s) with good progress on all fronts. We'll have an update on that once the snapshot takes place.

## Why is there nothing on github yet? The coins about to start trading, yet there's no code?!?!?!

Relax. The coin is not about to start trading yet and the code is there.

The 'official' repository at [heliumpay](https://github.com/heliumpay) is more or less empty as HLM is still weeks ahead of launch but [if you are in dire need of GitHubs please feel welcome.](https://github.com/gjhiggins/dash/tree/helium)

## What's HLM price going to be after snapshot?

It's whatever the market decides. When a seller and a buyer agree an exchange - that's the price. Not even the core developers know more than this. Any advice you can get is just speculation.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/56def32-Screenshot_from_2017-10-10_15-35-16.png",
        "Screenshot from 2017-10-10 15-35-16.png",
        489,
        262,
        "#c7ccd0"
      ]
    }
  ]
}
[/block]
## What will happen to any unclaimed Helium?

karmashark wrote:

>Any unclaimed Helium is owned by the network, opposed to @coins101, myself or any other team member. And since the Helium network owns the HLM, the network will vote on what they are to be used for once the redemption window closes.

>As of right now I am happy with a six (6) month window for redemption. We may chose to extend that window in the future to accommodate for stragglers and late comers.

**All helium obtained from the closed mining period will be burned.**

## Why was x11 chosen as the algoritm?

![Imgur](https://i.imgur.com/eTW7uVt.png)

_(Pinned in #general, starting with "We did discuss this issue at length")_


## Why no ICO? I want ERC20 tokens!

karmashark wrote:

>Many have asked why we are doing a coin redemption and a economic hard work / technical fork opposed to a straight ICO. This is a fair question and deserves an answer. Helium is not an ordinary project as it has deep ties dating back to DASH and more recently, Spreadcoin. The original plan was to make Spreadcoin into what Helium is going to be, a network of value utilizing both Master nodes and Service nodes. A plan was originally agreed upon to take Spreadcoin in this direction. Over time the lead developer on Spreadcoin brought forth a new vision which was not in alignment with the original plan - thus the economic fork of Spreadcoin and the technical fork of DASH. Since many of the previous members of Spreadcoin have come over to create Helium, we decided to keep as much of the old plan intact instead of starting over after several years of work. To understand the full history of Helium one must first read the Spreadcoin thread on BitcoinTalk.org, however here is a short summary on when and why we went in this direction:  [https://bitcointalk.org/index.php?topic=1045373.msg18030003#msg18030003](https://bitcointalk.org/index.php?topic=1045373.msg18030003#msg18030003)

##Pools?

The devs are verrrrrrry aware of the importance of a decent hash rate around launch so Pools will be made available upon launch. Keep an eye on the Slack.


## How high will the mining difficulty be at the beginning?

From Coins101:

> What a great question.
> 
> Bitcoin block 1 was mined 6 days after block 0, the genesis block.
> 
> https://blockchain.info/block/000000000019d6689c085ae165831e934ff763ae46a2a6c172b3f1b60a8ce26f
> https://blockchain.info/block/00000000839a8e6886ab5951d76f411475428afc90947ee320161bbf18eb6048
> 
> Blockchains take a while to come to life, in the case of Bitcoin roughly a week. If there are too many people mining immediately, the network will get into difficulty as the chain is too new and many forks will appear. It has the potential to be a bit of a mess.
> 
> This is why we'll keep everyone off the network for a while during which time we'll bring up the difficulty, which is effectively establishing a stable 'longest chain' for everyone to follow.
> 
> A while could be 1 week, 2 weeks, possibly 3 weeks. We'll determine when we think its reasonably safe, but with ASICS the start might be a difficult time (no pun intended). You'll get frustrated as hell during this period. Please feel free to take out your frustrations on me and no one else, as everyone else in the team will be working hard to try to get the network stable.
> 
> We wont profit from the rewards we'll earn during the closed mining period. We'll probably burn those coins.
> 
> We are expecting 2 pools to be up by the time you all get on the network.

# Nodes

## How much HLM do I need for a Masternode?

1000 HLM.


## What else will I need for a Masternode?

You'll need a VPS to host it on. You can of course host it on your home computer but a VPS is easier, safer and cheaper. As the launch date comes closer the HLM team will release guides on how to set everything up. 

Helium masternodes will not be much different from other masternode coins, so if you feel adventurous you can always buy a cheap masternode coin and set up a masternode for that to get  familiar with how everything works.
[nodeshare.in](http://nodeshare.in/coins/helium/order/), [node-vps.com](https://node-vps.com) and [MP hosting](https://mp-hosting.co.uk/cart.php?gid=12) will run dedicated hosting services for Helium masternodes. These providers have been community vetted.


## What are Servicenodes?

ServiceNodes will perform for profit related services. An Uber type model will be created where the network and users rate providers.

The initial focus will be for Service Nodes to run fast relay networks, called Decentralized Digital Services Networks (DSDN). These will enable anyone to run a full Bitcoin node for anyone else, for a fee. Or users can run their own secure Helium Nodes, Bitcoin nodes, Monero nodes, etc. Basically a cloud blockchain provider.

There is much more to learn as well so head over to the slack channel #servicenodes for in depth Q&A and read [the first public article](https://www.cryptocoinsnews.com/helium-bring-complex-global-supply-chains-onto-blockchain-launching-september/).


## Whats the difference between Masternode and Servicenodes?

> Masternodes support the network by hosting copies of the blockchain, therefore securing it.  Masternodes will be paid by allocating 45% of mining rewards out in a random payment schedule to these nodes.
> 
> Servicenodes will be hosting blockchains for third parties and will be paid by businesses/groups who are interested in that and or services the nodes are offering

By @misanthropicrage


## How much for a Servicenode?

It is undecided at this point, but devs have floated numbers between 5,000 HLM and 10,000 HLM. Devs have also stated that a service node may be priced as a flat rate in fiat, presumably so that the price remains somewhat fixed.

coins101 wrote:

>One of the things I want to avoid with Service Node is the barrier to entry on collateral. If we are asking you to buy a franchise, we can't also ask you to spend a lot of money on buying. 1,000 HLM right now it's relatively affordable, but what will happen in a few years time? 

>You'll be spending your working capital on buying the collateral and leaving you with little money to buy the franchise and then set-up your services.  

>That would potentially limit the numbers of people wanting to get involved. We do, however, need to have some collateral requirements. Perhaps this is the point at which we say that collateral for service nodes is flexible.

and:

>(...)one of my concerns is that we price out people who would otherwise be technically very good at running service nodes

# The vision

## How does Dash vs. Helium compare?

By @allomancer_jak
>Dash is trying to replace the usd as a means of everyday payment. Helium has a different direction for the project, so I personally do not consider them to be rivals. The money coming into Dash comes from a different place than where Helium money will come from (e.g. Enterprise investors and businesses paying us to use services offered by the Service Nodes).

Meaning Dash is targeting everyday users and Helium is targeting corporations with another kind of need.


## What's the deal with using Dash code and finding enterprise clients?

By @karmashark

> Both Coins and myself are following Evolution's, well, evolution (as closely as we possibly can). Dash has an advantage of having a large coffer of USD$ to fund their development out of. The flip side is we have a lot of real-world experience at the top as founders, Coins in the world of infrastructure and construction and myself in the blockchain space for half a decade and before that, BlackBerry for seven years.
> 
> Time to market is hard to predict unless they can see into our labs and we can see into theirs, which is not possible. That being said, we have a solid plan and some talent backing us along with business experience working with Enterprise clients. All I have done for the last decade is work with Enterprise, ditto for Coins. I think you will see both Dash and Helium will have compelling offerings with these releases however ours will be very polished as we have several years of development plans now beginning.  There is some patents as well which will add in another layer of beautiful complexity (we will have updates on this when ready, revolving around payments).


# Important dates

- SPR Snapshot: October 10th
- Helium release:  ~~Q4 2017~~ Q1 2018
- HLM claiming period: either 6 months or a year.


# Important links

- [Homepage](http://heliumpay.com/)
- [Whitepaper](http://heliumpay.com/img/WhitePaper.pdf)
- [Slack](https://heliumslack.herokuapp.com/)
- **[Helium News](https://goo.gl/forms/8flzE0N8mYppcKDE3)**  (Mailing list)
- [SPR Wallet](http://www.spreadcoin.info/downloads.php)
- [Initial announcement on BitcoinTalk](https://bitcointalk.org/index.php?topic=1809278.0)


# Community links

- [Korean community on Kakao](https://open.kakao.com/o/gTNCuoB)
- [Telegram community](https://t.me/HeliumPay)


# The Team

## Who are the HLM team?

Helium's team are @coins101, @karmashark/@KarmaWolf, @bitcoinkw, @ra, @craslovell, @cryptoconsultant and @richyjames as well as several others who'll remain behind the scenes for now. Read a bit more about the team [here.](https://www.heliumlabs.org/blog/october-25th-team-introduction)

In the meantime, Helium's most valuable asset is **you**. Decentralized means a couple of things and one of them is: if you want it, make it and if you make it its yours. So if you have something to add; drop by in #dev or hang around in #general and test the waters.

## What's the story with how Helium came to be?

@coins101 put it like this:

> I joined Spreadcoin in Feb 2015, after leaving DASH
> 
> just before Feb 2015, I spent several months trying to get the DASH lead dev to add services to DASH
> 
> he was focused only on competing with Bitcoin using only Instantx and coin mixing
> 
> I really wanted to go after services as Master nodes can do so much more than just coin mixing
> 
> I have been working on services for a second layer for a few years now, the first concept was to build accounts, so that people who knew zero about crypto could still use crypto the same way they use an online wallet service like Coinbase or PayPal
> 
> After I left, DASH investors liked that idea so much they got Evan to work on it - now called Evolution
> 
> We're building on that, but also adding some new dimensions associated with Smart Cities
> 
> The lead dev of Spreadcoin isn't a fan of Enterprise applications, so we've decided to part ways and so the work I and others have been doing for over 2 years will be moved into Helium


# Who writes the FAQ?

Currently this faq is written and maintained by @kristerv, @teela and you.

#Hall of Fame

**Snapshot MVP:**

@gjhiggins tied with @phire

**Mighty Mouse:**

@gj

**Super Saiyan:**

@kristerv

**the Rock:**

@bitcoinkw

**Bitcointalk top Ninja:**

@szfinx

**Tourney champions**: 

@rhinomonkey, Wielder of the Swarovski Crested Belly Putter, General der Flakartillerie.

@e1ghtspace, Master of the Purple Robot Unicorn. [Stringfellow Hawke](https://www.youtube.com/watch?v=l8syGlAMTKA)

@overbuilt, God Emperor of Dune.

**DISCLAIMER**: quotes in this faq are verbatim. They were pulled from Slack so interpunction, capitalization and paragraphing might be edited for the sake of readability. Also: this FAQ is community built, supported and maintained. So if you don't like it: go ahead and make your own FAQ with blackjack and hookers.