---
title: "Frequently Asked Questions OLD (pre oct 10th)"
excerpt: ""
---
**The Slack search button is your best friend. We've gathered most of the important stuff and put it in this FAQ for your convenience**

Join the [mailing list](https://goo.gl/forms/8flzE0N8mYppcKDE3) to stay updated.

# Snapshot

## When is the snapshot?

- **Block number 1657200**

coins101 wrote:

>Your coins should be at or heading to where they should be when the snapshot happens in just a few hours time.

>Remember, don't watch the clock, watch the block height for timing: 1657200

>https://chainz.cryptoid.info/spr/

>The blocks are moving faster since it started to be attacked earlier to speed up the chain and put people off guard.

coins101 wrote:

>A note from Cryptopia (no editing from us):

>1. Cryptopia will pause the SPR market about 30min before the snapshot block arrives.
>2. After the snapshot block arrives, we will credit the users with their helium balances
>3. after the snapshot process is complete and it's safe for users to sell their SPR, we will resume trading on the SPR market

The announcement on Cryptopia's website:

>The SPR markets will be paused shortly before Helium snapshot (estimated market close is currently 7:15pm UTC today). Please complete all pre-snapshot trades before then. The SPR markets will reopen after the snapshot of cryptopia user balances has been completed.

This timer keeps track of the blocks as well as the time:  http://heliumsnapshot.ga/
Be careful, its unofficial so use at your own discretion.

## Where should I keep my coins during the snapshot?

[Cryptopia](https://www.cryptopia.co.nz/) will be doing the airdrop so send your SPR there for an automatic process. You can also keep them in your SPR wallet, but then you'll have to do a manual signing process which will take much longer. For sure do not keep your coins on Bittrex.

## After block 1657200 can I sell my spread? Or do I have to wait until I receive my Helium?

coins101 wrote:

>If you really want to, yes. Why not keep them? I plan to. Spreadcoin has a great future.

>EXCHANGE

>We are expecting Cryptopia to capture how many Spreadcoins everyone has on their exchange at this block height.

>We will wait a few days before doing the actual snapshot download. Once we have a database of who owned what at block height 1657200, done some checks, we can begin thinking about the launch process.

>When the Helium chain is launched, we will generate enough coins at the start to give everyone at block height 1657200 the same number of Helium coins as they had on Spreadcoin.

>Cryptopia will tell us the total of all the account balances they have (not who you are individually) and after an audit, we will give them the number of Helium coins that match how many Spreadcoins they had on their books at the time of the snapshot block height.

>Once we send them all the Helium coins they have asked for, they will distribute them to all your accounts - 'Airdrop'.

>MANUAL

>If you are in control of your Spreadcoins (off exchange and on a public key where you have the actual private key), then you can start to make a claim for your Helium coins.

>This will take a real long time as we'll be busy with the launch process, making sure the network is stable, dealing with MN set-up questions, dealing with people attacking the network, dealing with new pool operators, dealing with new exchange discussions, starting off potential pilots, working on a patent application, flying off to have technical meetings about the Service Node network, etc, the list goes on and on (just setting some expectations on timing of 'rush jobs' people will be asking for).

>HOW LONG TO WAIT BEFORE MOVING COINS?

>How long do you have to wait before moving your coins around? That is a difficult question to answer. I personally am going to allow a minimum of 60 to 120 blocks (about 1 to 2 hrs). Take a look at discussions around the Bitcoin Cash fork and you'll see a range of discussions on this question. The variety of answers apply to us too. Some will say you should wait days, some a few minutes.

>You could take your chances and move coins after just a few blocks, but why take the risk?

You'll find the current block number in your (synced) wallet or on a block explorer: either [https://chainz.cryptoid.info/spr/](https://chainz.cryptoid.info/spr/) or [http://cryptoguru.tk/Blocks/index.php?Currency=SPR](http://cryptoguru.tk/Blocks/index.php?Currency=SPR).

Cryptopia will halt trading around block 1657200

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/09141cc-snapshot.png",
        "snapshot.png",
        481,
        231,
        "#d3d5d7"
      ]
    }
  ]
}
[/block]
## What's HLM price going to be after snapshot?

It's whatever the market decides. When a seller and a buyer agree an exchange - that's the price. Not even the core developers know more than this. Any advice you can get is just speculation.

## How do I claim my HLM when SPR is in local wallet?

There are tutorials on this site (check the left side menu), but since Helium is not out yet these tutorials are not exact.

Also check out [Coins101's more detailed explanation](https://hackmd.io/s/B1Gt73I2-)

##When will the Helium network launch?

Coins101 wrote:

>The snapshot date does not equal the launch of Helium or the release of a new Helium wallet. The snapshot date is just to fix all the balances when Helium does launch. It is a point in time when we freeze everything and move off the Spreadcoin timeline.

>We will not be providing details of the Helium launch as it poses a security risk. We'll likely give you a few hours notice when the network is ready for public release.

## When will the wallets be released?

karmashark wrote:

>Right now it is not possible to give a definitive time frame as there will be much work to do once the snapshot takes place for us behind the scenes. @coins101 answered 'much longer' and I would echo that sentiment. Weeks likely however this is just an estimate

>We have been and continue to work away on the wallet(s) with good progress on all fronts. We'll have an update on that once the snapshot takes place.

## What will happen to any unclaimed Helium?

karmashark wrote:

>Any unclaimed Helium is owned by the network, opposed to @coins101, myself or any other team member. And since the Helium network owns the HLM, the network will vote on what they are to be used for once the redemption window closes.

>As of right now I am happy with a six (6) month window for redemption. We may chose to extend that window in the future to accommodate for stragglers and late comers.

# Important dates

- SPR Snapshot: October 10th
- Helium release:  October ~
- HLM claiming period: either 6 months or a year.

# Important links

- [Homepage](http://heliumpay.com/)
- [Whitepaper](http://heliumpay.com/img/WhitePaper.pdf)
- [Slack](https://heliumslack.herokuapp.com/)
- **[Helium News](https://goo.gl/forms/8flzE0N8mYppcKDE3)**  (Mailing list)
- [SPR Wallet](http://www.spreadcoin.info/downloads.php)
- [Initial announcement on BitcoinTalk](https://bitcointalk.org/index.php?topic=1809278.0)

# Community links

[Korean community on Kakao](https://open.kakao.com/o/gTNCuoB)
[Telegram community](https://t.me/HeliumPay)

# Security notices

1. Hey @everyone **please be careful not to click on any phishing links sent in DM's**, especially from a user with 'ETH' in their name. We haven't had any problems yet, but there is someone doing the rounds in all crypto slacks. [by @coins101]

2. **Paper wallets are not secure** unless you know exactly what you're doing. We've had people lose thousands of coins already. [More info](https://bitcointalk.org/index.php?topic=1045373.msg20223325#msg20223325).

3. It's a great idea to **turn on 2FA for all important accounts**.  However also back up (for example write on paper) the code that you are given if using Google Authenticator. As if you lose your phone it's going to be a pain to restore your account.

4. **Never download the wallet from anywhere other than official sources** like the website or #announcements thread in Slack.

# Helium coins

## Where can I buy HLM?

You can buy SPR on [Cryptopia](https://www.cryptopia.co.nz/) and that will become HLM. You'll also get to keep your SPR so if you buy 1000 SPR then you'll keep that plus get an additional 1000 HLM. You can't buy HLM just yet as Helium is not public.

SpreadCoin will continue to exist, Helium will just branch out of it. Currently the SPR blockchain snapshot is planned to happen on October 10th. However Helium itself will become public some weeks later (date unknown). Also be careful not to call this a "swap", because you'll have both your SPR and an equal amount of HLM.

## But *how* do I convert SPR to HLM when the time comes?

Either you keep your coins on an exchange that supports the airdrop or follow a to-be-released tutorial.

To be updated either keep an eye out in the Slack or join the mailinglist

## Should I keep the coins on the exchange or move them to my own wallet?

Since Cryptopia agreed to cooperate then keeping your SPR there means you'll get your HLM automatically. Even though the devs seem pretty sure of the cooperation - nothing is ever guaranteed in crypto.

Technically you are 100% safe if your coins are on your own wallet, because you have your private key.

## Is there a recommended wallet to hold SpreadCoin in?

There's only one [downloadable one](http://www.spreadcoin.info/downloads.php), but you can also hold them on [Cryptopia](https://www.cryptopia.co.nz/)

## Should I buy SPR now or wait for HLM to come? Maybe the price will drop?

What's you're asking is basically speculation advice. Following Warren Buffets advice you should always look into what you're investing in as if it was your company and decide if it's a worthwhile investment yourself. He also suggests to buy only if the object is undervalued (have some error margin), but this still comes down to your personal research.

> FOMO is a bad bad bad advisor @kristerv

by @teela

Cryptocurrencies are a bit different in the sense that if you think too long you could totally miss the train. Also with HLM you're probably not trying to double your money, but get a masternode so there's more pressure to make sure you get it. While [FOMO](https://en.wikipedia.org/wiki/Fear_of_missing_out) is a horrible investment advisor if you have already decided to buy you should probably do it while you still can.

If you do calculations you would need a 50% drop in the market to buy 2x more coins, right? So if you buy 1000 HLM at $1 and the price gets to $200 you've got $200'000. However if you wait for the price to drop and buy 2000 HLM at $0.5 now you would get $400'000 - awesome. But **is doubling your money worth the risk of not getting it at all?**

Or as @richyjames put it:
> If you want a large amounts of coins you have no choice but to start. For smaller amounts can take gamble.

## Why was x11 chosen as the algoritm?

![Imgur](https://i.imgur.com/eTW7uVt.png)

_(Pinned in #general, starting with "We did discuss this issue at length")_

## Why no ICO? I want ERC20 tokens!

karmashark wrote:

>Many have asked why we are doing a coin redemption and a economic hard work / technical fork opposed to a straight ICO. This is a fair question and deserves an answer. Helium is not an ordinary project as it has deep ties dating back to DASH and more recently, Spreadcoin. The original plan was to make Spreadcoin into what Helium is going to be, a network of value utilizing both Master nodes and Service nodes. A plan was originally agreed upon to take Spreadcoin in this direction. Over time the lead developer on Spreadcoin brought forth a new vision which was not in alignment with the original plan - thus the economic fork of Spreadcoin and the technical fork of DASH. Since many of the previous members of Spreadcoin have come over to create Helium, we decided to keep as much of the old plan intact instead of starting over after several years of work. To understand the full history of Helium one must first read the Spreadcoin thread on BitcoinTalk.org, however here is a short summary on when and why we went in this direction:  [https://bitcointalk.org/index.php?topic=1045373.msg18030003#msg18030003](https://bitcointalk.org/index.php?topic=1045373.msg18030003#msg18030003)

## How high will the mining difficulty be at the beginning?

From Coins101:

> What a great question.
> 
> Bitcoin block 1 was mined 6 days after block 0, the genesis block.
> 
> https://blockchain.info/block/000000000019d6689c085ae165831e934ff763ae46a2a6c172b3f1b60a8ce26f
> https://blockchain.info/block/00000000839a8e6886ab5951d76f411475428afc90947ee320161bbf18eb6048
> 
> Blockchains take a while to come to life, in the case of Bitcoin roughly a week. If there are too many people mining immediately, the network will get into difficulty as the chain is too new and many forks will appear. It has the potential to be a bit of a mess.
> 
> This is why we'll keep everyone off the network for a while during which time we'll bring up the difficulty, which is effectively establishing a stable 'longest chain' for everyone to follow.
> 
> A while could be 1 week, 2 weeks, possibly 3 weeks. We'll determine when we think its reasonably safe, but with ASICS the start might be a difficult time (no pun intended). You'll get frustrated as hell during this period. Please feel free to take out your frustrations on me and no one else, as everyone else in the team will be working hard to try to get the network stable.
> 
> We wont profit from the rewards we'll earn during the closed mining period. We'll probably burn those coins.
> 
> We are expecting 2 pools to be up by the time you all get on the network.

# Nodes

## How much HLM do I need for a Masternode?

1000 HLM. Or currently that would be 1000 SPR.

## What else will I need for a Masternode?

You'll need a VPS to host it on. You can of course host it on your home computer but a VPS is easier, safer and cheaper. As the launch date comes closer the HLM team will release guides on how to set everything up. 

Helium masternodes will not be much different from other masternode coins, so if you feel adventurous you can always buy a cheap masternode coin and set up a masternode for that to get  familiar with how everything works.

Both [nodeshare.in](http://nodeshare.in/coins/helium/order/) and [node-vps.com](https://node-vps.com) will run dedicated hosting services for Helium masternodes.

## What are Servicenodes?

ServiceNodes will perform for profit related services. An Uber type model will be created where the network and users rate providers.

Our initial focus will be for Service Nodes to run fast relay networks, called Decentralized Digital Services Networks (DSDN). These will enable anyone to run a full Bitcoin node for anyone else, for a fee. Or users can run their own secure Helium Nodes, Bitcoin nodes, Monero nodes, etc. Basically a cloud blockchain provider.

There is much more to learn as well so head over to the slack channel #servicenodes for in depth Q&A and read [the first public article](https://www.cryptocoinsnews.com/helium-bring-complex-global-supply-chains-onto-blockchain-launching-september/).

## Whats the difference between Masternode and Servicesnode?

> Masternodes support the network by hosting copies of the blockchain, therefore securing it.  Masternodes will be paid by allocating 45% of mining rewards out in a random payment schedule to these nodes.
> 
> Servicenodes will be hosting blockchains for third parties and will be paid by businesses/groups who are interested in that and or services the nodes are offering

By @misanthropicrage

## How much for a Servicenode?

It is undecided at this point, but devs have floated numbers between 5,000 HLM and 10,000 HLM. Devs have also stated that a service node may be priced as a flat rate in fiat, presumably so that the price remains somewhat fixed.

# The vision

## How does Dash vs. Helium compare?

By @allomancer_jak
>Dash is trying to replace the usd as a means of everyday payment. Helium has a different direction for the project, so I personally do not consider them to be rivals. The money coming into Dash comes from a different place than where Helium money will come from (e.g. Enterprise investors and businesses paying us to use services offered by the Service Nodes).

Meaning Dash is targeting everyday users and Helium is targeting corporations with another kind of need.

## What's the deal with using Dash code and finding enterprise clients?

By @karmashark

> Both Coins and myself are following Evolution's, well, evolution (as closely as we possibly can). Dash has an advantage of having a large coffer of USD$ to fund their development out of. The flip side is we have a lot of real-world experience at the top as founders, Coins in the world of infrastructure and construction and myself in the blockchain space for half a decade and before that, BlackBerry for seven years.
> 
> Time to market is hard to predict unless they can see into our labs and we can see into theirs, which is not possible. That being said, we have a solid plan and some talent backing us along with business experience working with Enterprise clients. All I have done for the last decade is work with Enterprise, ditto for Coins. I think you will see both Dash and Helium will have compelling offerings with these releases however ours will be very polished as we have several years of development plans now beginning.  There is some patents as well which will add in another layer of beautiful complexity (we will have updates on this when ready, revolving around payments).

# The team

## Who are the HLM devs?

coins101, karmashark and conradprogrammer, with some initial support from gjhiggins. They seem to have been around for a long time and taken part in Dash.

## What's the story with how Helium came to be?

@coins101 put it like this:

> I joined Spreadcoin in Feb 2015, after leaving DASH
> 
> just before Feb 2015, I spent several months trying to get the DASH lead dev to add services to DASH
> 
> he was focused only on competing with Bitcoin using only Instantx and coin mixing
> 
> I really wanted to go after services as Master nodes can do so much more than just coin mixing
> 
> I have been working on services for a second layer for a few years now, the first concept was to build accounts, so that people who knew zero about crypto could still use crypto the same way they use an online wallet service like Coinbase or PayPal
> 
> After I left, DASH investors liked that idea so much they got Evan to work on it - now called Evolution
> 
> We're building on that, but also adding some new dimensions associated with Smart Cities
> 
> The lead dev of Spreadcoin isn't a fan of Enterprise applications, so we've decided to part ways and so the work I and others have been doing for over 2 years will be moved into Helium

# Who's writing this FAQ?

It's community written. Ask around for the edit link.