---
title: "How to be your own VPS provider"
excerpt: ""
---
**By AKcryptoGUY**

This Guide will show you how to download and install the Hyper-V Server operating system onto a server or computer so that you can create virtual or “guest” computers in a virtualized environment. Using the methods described in these Guides, you will be able to use one physical computer to host several virtual Windows or Linux computers which could each run cryptocurrency wallets or masternodes without the need for you to purchase virtual hosting or VPS from a third party.
<br>
**Video Guide:**

[https://www.youtube.com/playlist?list=PLTblguczzdyajCPQGlpJjHUvSNV8WNsGQ](https://www.youtube.com/playlist?list=PLTblguczzdyajCPQGlpJjHUvSNV8WNsGQ)
<br>
**Text Guide on Medium:**

[Part 1: Download and Install Hyper-V Server 2016](https://medium.com/@AKcryptoGUY/download-and-install-hyper-v-server-2016-35ea36f43ff4)

[Part 2: Configure Microsoft Hyper-V Server 2016](https://medium.com/@AKcryptoGUY/configure-microsoft-hyper-v-server-2016-9500dbdf5f18)

[Part 3: Remotely Configure Hyper-V Server 2016](https://medium.com/@AKcryptoGUY/remotely-configure-hyper-v-server-2016-865e772f3df5)

[Part 4: How to Create Your First Virtual Machine](https://medium.com/@AKcryptoGUY/how-to-create-your-first-virtual-machine-c4711eda2e37)

[Part 5: How to Secure and Harden Your VPS](https://medium.com/@AKcryptoGUY/how-to-secure-vps-hyper-v-9ceee0d1c2a9)