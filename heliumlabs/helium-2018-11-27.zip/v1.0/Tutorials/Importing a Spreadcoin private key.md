---
title: "Importing a Spreadcoin private key"
excerpt: ""
---
We've made it as easy as possible to claim your Helium coins.

You'll need your Spreadcoin wallet (or your private key) and the Helium wallet.

As a security precaution: disconnect from the internet before you start. **NEVER SHARE YOUR PRIVATE KEYS.**

Open your Spreadcoin wallet. Click **Tools** then **Debug Console**. If your wallet is encrypted, first enter ```walletpassphrase YOURPASSWORD 120```. This unlocks it for 120 seconds. Once unlocked, enter the following command: ```dumpprivkey SgCRnxFvBuUxR4KVKjo1MhMuHf6HryFVXz``` where the latter is your own Spreadcoin address. 
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/358a6b4-wallet1.png",
        "wallet1.png",
        1045,
        630,
        "#d2c9d0"
      ]
    }
  ]
}
[/block]
Copy the output and open your Helium wallet. In your Helium wallet go to **Tools** then **Debug Console** and enter ```importspreadprivkey 7S3MYZnzDL6dqPXChLiCDUYNo6w7o353Q9uxgwVbXpCWb6MJjKG``` where the latter is the private key from your own Spreadcoin address.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/89cf348-wallet2.png",
        "wallet2.png",
        1043,
        758,
        "#e0e2e7"
      ]
    }
  ]
}
[/block]
Copy some random text to clear your clipboard and turn your internet back on. After the  Helium wallet is synced you will see your balance.

- If your Helium balance is not what you expected: check your Spreadcoin wallet and make sure your coins aren't sitting in a change address.

- If you accidentally sent your SPR to an uncompressed paper wallet: you can still claim your Helium by using the <code>importprivkey</code> command.