---
title: "How to vote for a budget proposal"
excerpt: ""
---
**Under construction**

Below is a guide on how to vote on budget proposals as a Masternode owner. Within the Helium Governance Network any Masternode owner can vote on budget proposals put forward by the community. You can read a bit more about the Governance system here: LINK TBA. You can find a guide on creating proposals [here.](https://www.heliumlabs.org/v1.0/docs/how-to-create-a-budget-proposal) 

Voting on a budget proposal can be done in two ways: through the **Debug Console** in the wallet or on the command line. You should vote from your local controller wallet.

Cryptotron has already made a proposal explorer available here: [http://heliumstats.online/governance/](http://heliumstats.online/governance/). We will continue to work on adding supporting infrastructure. You can also find all information through the console (or command line).

#1 - Find active proposals.

There are three essential console commands that give information about currently active budget proposals:

- `mnbudget show` will show all proposals and their status.
- `mnbudget getinfo PROPOSALNAME` will show info of that specific proposal. 
- `mnbudget projection` will show the active proposals that have passed the vote and will be paid in next cycle. Note that these commands are subject to syncing and may a while/a few tries to show up to date information.

A sample `mnbudget getinfo PROPOSALNAME` looks like this:

```{
“Name” : “PROPOSALNAME”,
“Hash” : “ed2f83cedee59a91406f5f47ec4d60bf5a7f9ee6293913c82976bd2d3a658041”,
“FeeHash” : “d83c17a0a9af1c253c5cc5f95651b768a4d044cabf07a386777ee8127e20528e”,
“URL” : “https://tinyurl.com/y9f9gfo”,
“BlockStart” : 86400,
“BlockEnd” : 129600,
“TotalPaymentCount” : 1,
“RemainingPaymentCount” : 1,
“PaymentAddress” : “SZBnTFogAq5WhoCFZpYrBCPpBLgBrTUGhA”,
“Ratio” : 1.00000000,
“Yeas” : 240,
“Nays” : 17,
“Abstains” : 0,
“TotalPayment” : 1000.00000000
“MonthlyPayment” : 1000.00000000,
“IsEstablished” : true,
“IsValid” : true,
“fValid” : true
}```

Everything is pretty self explanatory. The most important entries when voting are `URL` and `Hash`. The `URL` entry should link to a description of the proposal. The `Hash` is the value that will be used to cast the actual vote.

#2 - Casting a vote.

To cast a vote: note the `Hash` of the proposal you'd like to vote on and open the **Debug Console** (or open a terminal window for the command line).

In the **Debug Console**:

To vote YES with all Masternodes: `mnbudget vote-many HASH yes`
To vote NO with all Masternodes: `mnbudget vote-many HASH no`

For the example in step 1 the command would look like this:

`mnbudget vote-many ed2f83cedee59a91406f5f47ec4d60bf5a7f9ee6293913c82976bd2d3a658041 yes`

And that's it! You have done your democratic duty and the DAO thanks you :)