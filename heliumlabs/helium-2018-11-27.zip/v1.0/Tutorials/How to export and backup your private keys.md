---
title: "How to export and backup your private keys"
excerpt: ""
---
**By AKcryptoGUY**

In this video I will demonstrate how to export and backup the private keys for your Helium wallet, and save them in an encrypted file using Steganos Locknote. 
[block:embed]
{
  "html": "<iframe class=\"embedly-embed\" src=\"//cdn.embedly.com/widgets/media.html?src=https%3A%2F%2Fwww.youtube.com%2Fembed%2FLSwBZNyo2sw%3Ffeature%3Doembed&url=http%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3DLSwBZNyo2sw&image=https%3A%2F%2Fi.ytimg.com%2Fvi%2FLSwBZNyo2sw%2Fhqdefault.jpg&key=f2aa6fc3595946d0afc3d76cbbd25dc3&type=text%2Fhtml&schema=youtube\" width=\"854\" height=\"480\" scrolling=\"no\" frameborder=\"0\" allow=\"autoplay; fullscreen\" allowfullscreen=\"true\"></iframe>",
  "url": "https://www.youtube.com/watch?v=LSwBZNyo2sw",
  "title": "How to Export and backup Helium wallet private keys",
  "favicon": "https://s.ytimg.com/yts/img/favicon-vfl8qSV2F.ico",
  "image": "https://i.ytimg.com/vi/LSwBZNyo2sw/hqdefault.jpg"
}
[/block]
#**Stay in Touch **

[Twitter](https://twitter.com/AKcryptoGUY)
[Medium](https://medium.com/@AKcryptoGUY)  
[Facebook](https://www.facebook.com/AKcryptoGUY)  
[Instagram](https://www.instagram.com/akcryptoguy)  
[YouTube](https://www.youtube.com/channel/UCIFu9OZWOtfxokGdFY6aTog) 


#**Links**

[Steganos Locknote](https://sourceforge.net/projects/locknote/)
[Helium Wallet](www.github.com/heliumchain/helium/releases)

#**Credits**

Music – The Darkness – MK2


#**Affiliate Links**

[Windscribe VPN: Your online privacy is under attack](https://windscribe.com/?affid=myxd75vi)  


**If I helped you save, please consider helping me earn. **

BTC: 3LbUJVW9WmXPgFStTXSLTBwjpnbVTtt8Ja 
TRON: TLsday62mhM67Sv5G5Z5Ju66TezJuVFbiw 
DGB: DUJ8W8QpmVex87posFPoDYGg5FrYCoMLGq 
DOGE: DH9Sj3DQNVBaxb6kZBXc6X2MPQjbv7H6oy 
ETH: 0xF2c21D9aCa782560169e23Cc83Ed195F9A3eA761