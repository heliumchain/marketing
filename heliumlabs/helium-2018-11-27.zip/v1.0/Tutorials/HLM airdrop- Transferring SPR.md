---
title: "HLM airdrop: Transferring SPR"
excerpt: ""
---
The HLM airdrop is scheduled for October 10th 10:00am New Zealand Time (UTC+12). To make sure you can claim the airdrop, the safest way is to use a local Spread wallet you have the private keys for.

This tutorial lays out the steps to do just that before that snapshot date.
[block:api-header]
{
  "type": "basic",
  "title": "1. Setup and secure local Spread wallet"
}
[/block]
Visit http://www.spreadcoin.info/downloads.php, download the wallet for your system, run the setup tool, encrypt your local wallet with a secure passphrase. Remember your passphrase and backup your wallet. 
[block:embed]
{
  "html": "<iframe class=\"embedly-embed\" src=\"//cdn.embedly.com/widgets/media.html?src=https%3A%2F%2Fwww.youtube.com%2Fembed%2FjGXf2xFyWaE%3Ffeature%3Doembed&url=http%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3DjGXf2xFyWaE&image=https%3A%2F%2Fi.ytimg.com%2Fvi%2FjGXf2xFyWaE%2Fhqdefault.jpg&key=f2aa6fc3595946d0afc3d76cbbd25dc3&type=text%2Fhtml&schema=youtube\" width=\"640\" height=\"480\" scrolling=\"no\" frameborder=\"0\" allowfullscreen></iframe>",
  "url": "https://www.youtube.com/watch?v=jGXf2xFyWaE",
  "title": "Install, Backup And Restore A Bitcoin Wallet. Or, Almost Any CryptoCoin Wallet (Windows)",
  "favicon": "https://s.ytimg.com/yts/img/favicon-vfl8qSV2F.ico",
  "image": "https://i.ytimg.com/vi/jGXf2xFyWaE/hqdefault.jpg"
}
[/block]
All CryptoCoin wallets work basically the same, SPR being no exception.
[block:api-header]
{
  "title": "2. Extract SPR receiving address from wallet to transfer SPR funds to"
}
[/block]
Define a label, e.g. "Helium Transfer Hold", select the address, press button "Copy Address" and remember this receiving address, in this example "Sd7mhYZFo1u7nw9rS2AChtvXtssKf6jnrU"
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/0f0c544-Group_5.png",
        "Group 5.png",
        1046,
        477,
        "#e9e8e7"
      ]
    }
  ]
}
[/block]

[block:api-header]
{
  "title": "3. Transfer SPR from exchange  to local wallet"
}
[/block]
Find the deposit function on your exchange and specify the receiving adress you took down in the last step. Confirm transfer. An exchange typically will claim fees for their service, so you probably will not be able to transfer 100% of your funds.

Example for Cryptopia:
[block:embed]
{
  "html": "<iframe class=\"embedly-embed\" src=\"//cdn.embedly.com/widgets/media.html?src=https%3A%2F%2Fwww.youtube.com%2Fembed%2FykWYQ5vZBh0%3Ffeature%3Doembed&url=http%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3DykWYQ5vZBh0&image=https%3A%2F%2Fi.ytimg.com%2Fvi%2FykWYQ5vZBh0%2Fhqdefault.jpg&key=f2aa6fc3595946d0afc3d76cbbd25dc3&type=text%2Fhtml&schema=youtube\" width=\"854\" height=\"480\" scrolling=\"no\" frameborder=\"0\" allowfullscreen></iframe>",
  "url": "https://www.youtube.com/watch?v=ykWYQ5vZBh0",
  "title": "Cryptopia Tutorial - Deposits and Withdrawals",
  "favicon": "https://s.ytimg.com/yts/img/favicon-vfl8qSV2F.ico",
  "image": "https://i.ytimg.com/vi/ykWYQ5vZBh0/hqdefault.jpg"
}
[/block]
In Bittrex first search for the Spread Coin wallet then press the "-" button to place a deposit order.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/0a06e82-Group_3.png",
        "Group 3.png",
        1355,
        337,
        "#2c373e"
      ]
    }
  ]
}
[/block]
Paste your local wallet receiving address, type in the amount of Spread you want to transfer (you should transfer all coins you got for the airdrop!) and confirm withdraw.


[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/91167aa-Group_6.png",
        "Group 6.png",
        682,
        641,
        "#374c3f"
      ]
    }
  ]
}
[/block]
If your local wallet is already fully synced, it should take only a few minutes for the transfer to show up in your balance.

If you have not had enough time to sync your wallet yet, do not worry, you can check the successful transfer at the [block explorer](https://chainz.cryptoid.info/spr/), just search for your receiving adress. When the transfer shows up here, you are good to go. 
[block:api-header]
{
  "title": "4. Wait for local SPR wallet to fully sync, until you see your balance"
}
[/block]
The full sync may take a few days (depending on internet connection) but do not worry, you have at least 6 months to claim your HLM airdrop.
[block:api-header]
{
  "title": "5. Claim HLM"
}
[/block]
It is not yet fully known how the claiming process will work. You will probably need to sign a message from your Spread wallet, similar to what is shown in the following video.

You will most likely not have to send your Spread coins to a third party, so you are never risking losing your Spread.
[block:embed]
{
  "html": "<iframe class=\"embedly-embed\" src=\"//cdn.embedly.com/widgets/media.html?src=https%3A%2F%2Fwww.youtube.com%2Fembed%2FmV8l6MPOtSU%3Ffeature%3Doembed&url=http%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3DmV8l6MPOtSU&image=https%3A%2F%2Fi.ytimg.com%2Fvi%2FmV8l6MPOtSU%2Fhqdefault.jpg&key=f2aa6fc3595946d0afc3d76cbbd25dc3&type=text%2Fhtml&schema=youtube\" width=\"854\" height=\"480\" scrolling=\"no\" frameborder=\"0\" allowfullscreen></iframe>",
  "url": "https://www.youtube.com/watch?v=mV8l6MPOtSU",
  "title": "How to sign a message with the Spreadcoin Wallet (for HLM swap)",
  "favicon": "https://s.ytimg.com/yts/img/favicon-vfl8qSV2F.ico",
  "image": "https://i.ytimg.com/vi/mV8l6MPOtSU/hqdefault.jpg"
}
[/block]