---
title: "How to harden a new Linux VPS"
excerpt: "Basic security and monitoring practices for hardening a new Linux server."
---
Masternodes have been designed to work in a hot/cold setup. The actual 1000 coins you need to setup your Helium masternode can be stored in an offline cold wallet (your personal PC, for example) and then you appoint an online hot wallet with no actual coins to act on behalf of the cold storage node. This allows you to always keep control of your private keys. To sum up, the private key is not on the VPS.

**The objective of an attacker doesn't have to be your wallet, it can be your VPS as well.** 
[block:callout]
{
  "type": "warning",
  "title": "Disclaimer",
  "body": "This guide is in development and should be further tested. Although there is no danger of damaging anything, I am not responsible for the loss of time if the result obtained is not the desired one.\n\n**Ubuntu** Completed: ✔️ / Tested: ✔️\n**Debian** Completed: ❌ / Tested: ✔️\n**CentOS** Completed: ❌ / Tested: ❌\n**Fedora** Completed: ❌ / Tested: ❌"
}
[/block]

[block:api-header]
{
  "title": "1. Update your server"
}
[/block]
The first thing you always need to do. You can update your VPS with the following command:
[block:code]
{
  "codes": [
    {
      "code": "apt-get update -y && apt-get upgrade -y",
      "language": "c",
      "name": "Ubuntu / Debian"
    },
    {
      "code": "yum -y update",
      "language": "c",
      "name": "CentOS / Fedora"
    }
  ]
}
[/block]
This command will update all your system’s packages to their latest version.
[block:api-header]
{
  "type": "basic",
  "title": "2. Create a non-root user"
}
[/block]
We recommend creating a limited user account and using that at all times. Administrative tasks will be done using *sudo* to temporarily elevate your limited user’s privileges so you can administer your VPS.

**1.1-**Create the user, replacing *example_user* with your desired username. You’ll then be asked to assign the user a password: 
[block:code]
{
  "codes": [
    {
      "code": "adduser example_user",
      "language": "c",
      "name": "Ubuntu"
    },
    {
      "code": "// Note: for CentOS and Fedora you have to add a password too\n\nuseradd example_user && passwd example_password",
      "language": "c",
      "name": "CentOS / Fedora"
    },
    {
      "code": "// Debian does not include sudo by default so it must be installed:\napt install sudo\n\n// Create the user, replacing example_user with your desired username. \n// You’ll then be asked to assign the user a password:\nadduser example_user",
      "language": "c",
      "name": "Debian"
    }
  ]
}
[/block]
**1.2-**Add the user to the *sudo* group so you’ll have administrative privileges:
[block:code]
{
  "codes": [
    {
      "code": "adduser example_user sudo",
      "language": "c",
      "name": "Ubuntu"
    },
    {
      "code": "usermod -aG wheel example_user\n\n// In CentOS 6 a wheel group is disabled by default for sudo access. You must to configure it manually. Type from root: `/usr/sbin/visudo`. Then find the line `# %wheel` and uncomment this line. To began typing in vi, press `a`. To save and exit press `Escape`, then type `:w`(press enter), `:q`(press enter)",
      "language": "c",
      "name": "CentOS / Fedora"
    },
    {
      "code": "adduser example_user sudo",
      "language": "c",
      "name": "Debian"
    }
  ]
}
[/block]
After creating your limited user, disconnect from your VPS and log back in as your new user.Now you can administer your VPS from your new user account instead of root. Nearly all superuser commands can be executed with sudo (example: *sudo iptables -L -nv*) and those commands will be logged to */var/log/auth.log*.
[block:api-header]
{
  "title": "3. Create an Authentication Key-pair"
}
[/block]
This is done on your local computer, not your VPS, and will create a 4096-bit RSA key-pair. During creation, you will be given the option to encrypt the private key with a passphrase. This means that it cannot be used without entering the passphrase unless you save it to your local desktop’s keychain manager. We suggest you use the key-pair with a passphrase, but you can leave this field blank if you don’t want to use one. Some VPS providers, including Digital Ocean, offer Linux installations with key authentication included. Especially when setting up multiple nodes this option will save you a lot of time. [Read more here.](https://www.digitalocean.com/community/tutorials/how-to-use-ssh-keys-with-digitalocean-droplets)

## **2.a) Linux / OS X** 
[block:callout]
{
  "type": "danger",
  "body": "If you’ve already created an RSA key-pair, this command will overwrite it, potentially locking you out of other systems. If you’ve already created a key-pair, skip this step. To check for existing keys, run ls ~/.ssh/id_rsa*.",
  "title": "Caution"
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "ssh-keygen -b 4096",
      "language": "c",
      "name": "Linux / OS X"
    }
  ]
}
[/block]
Press **Enter** to use the default names *id_rsa* and *id_rsa.pub* in */home/your_username/.ssh* before entering your passphrase.

Now upload the public key to your VPS. Replace *example_user* with the name of the user you plan to administer the VPS as, and *203.0.113.10* with your VPS’s IP address.
[block:code]
{
  "codes": [
    {
      "code": "// From your local computer:\nssh-copy-id example_user@203.0.113.10",
      "language": "c",
      "name": "Linux"
    },
    {
      "code": "// On your VPS (while signed in as your limited user):\nmkdir -p ~/.ssh && sudo chmod -R 700 ~/.ssh/\n\n// From your local computer:\nscp ~/.ssh/id_rsa.pub example_user@203.0.113.10:~/.ssh/authorized_keys",
      "language": "c",
      "name": "OSX"
    }
  ]
}
[/block]
## **2.b) Windows**
[block:html]
{
  "html": "<div>Follow this awesome guide from <a href=\"https://www.linode.com/docs/security/use-public-key-authentication-with-ssh/#windows-operating-system\" target=\"_blank\">Linode Docs</a></div>\n\n<style></style>\n"
}
[/block]

[block:api-header]
{
  "title": "4. Change SSH config"
}
[/block]
By default, password authentication is used to connect to your VPS via SSH. A cryptographic key-pair is more secure because a private key takes the place of a password, which is generally much more difficult to brute-force. In this section, we’ll create a key-pair and configure the VPS to not accept passwords for SSH logins.
[block:code]
{
  "codes": [
    {
      "code": "// Install nano text editor (if you know how to use any other you can use it too)\nsudo apt-get install nano -y\n\n// Open the config file\nsudo nano /etc/ssh/sshd_config\n  \n// Press Ctrl + X to close nano.\n// If you have made changes the program will ask you if you want to save it.",
      "language": "c",
      "name": "Linux"
    }
  ]
}
[/block]
All these configurations are commented (with a # at the beginning of the line) or are disabled by default. You will have to manually search for the settings you want to change in the file.

**4.1-Disallow root logins over SSH.** This requires all SSH connections be by non-root users. Once a limited user account is connected, administrative privileges are accessible either by using *sudo* or changing to a root shell using *su -*.
[block:code]
{
  "codes": [
    {
      "code": "# Authentication:\nPermitRootLogin no",
      "language": "coffeescript",
      "name": "File"
    }
  ]
}
[/block]
**4.2-Disable SSH password authentication.** This requires all users connecting via SSH to use key authentication. Depending on the Linux distribution, the line *PasswordAuthentication* may need to be added, or uncommented by removing the leading *#*.
[block:code]
{
  "codes": [
    {
      "code": "# Change to no to disable tunnelled clear text passwords\nPasswordAuthentication no",
      "language": "coffeescript",
      "name": "File"
    }
  ]
}
[/block]

[block:callout]
{
  "type": "info",
  "body": "You may want to leave password authentication enabled if you connect to your Linode from many different computers. This will allow you to authenticate with a password instead of generating and uploading a key-pair for every device.",
  "title": "Note"
}
[/block]
**4.3-Listen on only one internet protocol.** The SSH daemon listens for incoming connections over both IPv4 and IPv6 by default. Unless you need to SSH into your VPS using both protocols, disable whichever you do not need. This does not disable the protocol system-wide, it is only for the SSH daemon.

Use the option:
[block:code]
{
  "codes": [
    {
      "code": "# To listen only on IPv4.\nAddressFamily inet\n  \n# To listen only on IPv6.\nAddressFamily inet6",
      "language": "coffeescript",
      "name": "File"
    }
  ]
}
[/block]
The *AddressFamily* option is usually not in the sshd_config file by default. Add it to the end of the file:
[block:code]
{
  "codes": [
    {
      "code": "// Execute this command\necho 'AddressFamily inet' | sudo tee -a /etc/ssh/sshd_config",
      "language": "c",
      "name": "Linux"
    }
  ]
}
[/block]
**4.4-Change default port.** The Secure Shell (SSH) Protocol by default uses port 22. Accepting this value does not make your system insecure, nor will changing the port provide a significant variance in security. However, changing the default SSH port will stop many automated attacks and a bit harder to guess which port SSH is accessible from. In other words, a little security through obscurity.
[block:callout]
{
  "type": "warning",
  "body": "The Internet Assigned Numbers Authority (IANA) is responsible for the global coordination of the DNS Root, IP addressing, and other Internet protocol resources. It is good practice to follow their port assignment guidelines. Having said that, port numbers are divided into three ranges: Well Known Ports, Registered Ports, and Dynamic and/or Private Ports. The Well Known Ports are those from 0 through 1023 and SHOULD NOT be used. Registered Ports are those from 1024 through 49151 should also be avoided too. **Dynamic and/or Private Ports are those from 49152 through 65535 and can be used**. Though nothing is stopping you from using reserved port numbers, our suggestion may help avoid technical issues with port allocation in the future.",
  "title": "Note"
}
[/block]

[block:code]
{
  "codes": [
    {
      "code": "# SSH Port - Change the number 50022 to the port number you want.\nPort 50022",
      "language": "coffeescript"
    }
  ]
}
[/block]
**4.5-**Restart the SSH service to load the new configuration.
[block:code]
{
  "codes": [
    {
      "code": "sudo systemctl restart sshd",
      "language": "c",
      "name": "CentOS 7, Debian 8, Fedora, Ubuntu 15.10+"
    },
    {
      "code": "sudo service ssh restart",
      "language": "c",
      "name": "CentOS 6, Debian 7, Ubuntu 14.04"
    }
  ]
}
[/block]

[block:api-header]
{
  "title": "5. Install a firewall."
}
[/block]
Using a firewall to block unwanted inbound traffic to your VPS provides a highly effective security layer. By being very specific about the traffic you allow in, you can prevent intrusions and network mapping. A best practice is to allow only the traffic you need and deny everything else.

UFW is included in Ubuntu by default but must be installed in CentOS, Fedora and Debian. Debian will start UFW’s systemd unit automatically and enable it to start on reboots. This is not the same as telling UFW to enable the firewall rules, as enabling UFW with systemd or upstart only tells the init system to switch on the UFW daemon.
[block:code]
{
  "codes": [
    {
      "code": "// Install UFW\nsudo apt-get install ufw",
      "language": "c",
      "name": "Debian / Ubuntu"
    },
    {
      "code": "// By default, UFW is not available in CentOS repository.\n// So you will need to install the EPEL repository to your system.\nyum install epel-release -y\n\n//Then, we can install it from the EPEl repository.\nyum install --enablerepo=\"epel\" ufw -y",
      "language": "c",
      "name": "CentOS / Fedora"
    }
  ]
}
[/block]
**Set Default Rules.** Most systems will need a only a small number of ports open for incoming connections, and all remaining ports closed. To deny all incoming and allow all outgoing connections, run:
[block:code]
{
  "codes": [
    {
      "code": "sudo ufw default allow outgoing\nsudo ufw default deny incoming",
      "language": "c",
      "name": "Debian / Ubuntu / CentOS / Fedora"
    }
  ]
}
[/block]
**Add Rules.** Rules can be added in two ways: By denoting the port number or by using the service name.
[block:code]
{
  "codes": [
    {
      "code": "// To allow both incoming and outgoing connections on port 50022 for SSH.\n// Change the number 50022 to the port number you set earlier in the SSH configuration.\nsudo ufw allow 50022\n  \n// Similarly, to deny traffic on a certain port (in this example, 111)\nsudo ufw deny 111\n  \n// To remove a rule, add delete before the rule implementation.\nsudo ufw delete allow 80\n  \n// We have to open the port for the Helium masternode\nsudo ufw allow 9009",
      "language": "c",
      "name": "Debian / Ubuntu / CentOS / Fedora"
    }
  ]
}
[/block]
**Enable the Firewall.** To enable UFW and enforce your firewall rules:
[block:code]
{
  "codes": [
    {
      "code": "// Check status\nsudo ufw status\n\n// Enable UFW\nsudo ufw enable\n\n// Disable UFW\nsudo ufw disable",
      "language": "c",
      "name": "Debian / Ubuntu / CentOS / Fedora"
    }
  ]
}
[/block]
That's all we need. If you need more info check the original [doc](https://www.linode.com/docs/security/firewalls/configure-firewall-with-ufw/).
[block:api-header]
{
  "title": "6. Install Fail2Ban"
}
[/block]
Fail2Ban is an application that bans IP addresses from logging into your server after too many failed login attempts. Since legitimate logins usually take no more than three tries to succeed (and with SSH keys, no more than one), a server being spammed with unsuccessful logins indicates attempted malicious access.
[block:code]
{
  "codes": [
    {
      "code": "// Install it\nsudo apt-get install fail2ban",
      "language": "c",
      "name": "Ubuntu / Debian"
    },
    {
      "code": "// Install it\nsudo yum install fail2ban\n\n// Start and enable Fail2ban\nsudo systemctl start fail2ban\nsudo systemctl enable fail2ban",
      "language": "c",
      "name": "CentOS"
    },
    {
      "code": "// Install it\nsudo dnf install fail2ban\n  \n// Start and enable Fail2ban\nsudo systemctl start fail2ban\nsudo systemctl enable fail2ban",
      "language": "c",
      "name": "Fedora"
    }
  ]
}
[/block]
Fail2Ban can monitor a variety of protocols including SSH, HTTP, and SMTP. By default, Fail2Ban monitors SSH only and is a helpful security deterrent for any server since the SSH daemon is usually configured to run constantly and listen for connections from any remote IP address.

With the default configuration is enough, but if you want to configure it you can see the [full guide](https://www.linode.com/docs/security/using-fail2ban-for-security/).
[block:api-header]
{
  "title": "7. Set the timezone and install NTP"
}
[/block]
Setting your server's clock and timezone properly is essential in ensuring the healthy operation of distributed systems and maintaining accurate log timestamps. 
[block:code]
{
  "codes": [
    {
      "code": "// Check if dbus is installed\nsudo apt-get install dbus\n\n// List all timezones\ntimedatectl list-timezones\n\n// Press Space to scroll to the next page, b to scroll back a page.\n// Once you find the timezone you want to use, press q to go back to the command line.\n\n// Set the desired timezone - replace desired_timezone with the timezone you selected\nsudo timedatectl set-timezone desired_timezone\n\n// Verify that the timezone has been set properly\ntimedatectl\n\n// Install NTP for synchronization\nsudo apt-get install ntp",
      "language": "c",
      "name": "Ubuntu / Debian"
    },
    {
      "code": "// List all timezones\ntimedatectl list-timezones\n\n// Press Space to scroll to the next page, b to scroll back a page.\n// Once you find the timezone you want to use, press q to go back to the command line.\n\n// Set the desired timezone - replace desired_timezone with the timezone you selected\nsudo timedatectl set-timezone desired_timezone\n\n// Verify that the timezone has been set properly\ntimedatectl\n\n// Install NTP for synchronization\nsudo yum install ntp\n\n// Start and enable the service\nsudo systemctl start ntpd\nsudo systemctl enable ntpd",
      "language": "c",
      "name": "CentOS"
    },
    {
      "code": "// List all timezones\ntimedatectl list-timezones\n\n// Press Space to scroll to the next page, b to scroll back a page.\n// Once you find the timezone you want to use, press q to go back to the command line.\n\n// Set the desired timezone - replace desired_timezone with the timezone you selected\nsudo timedatectl set-timezone desired_timezone\n\n// Verify that the timezone has been set properly\ntimedatectl\n\n// Install NTP for synchronization\nsudo dnf -y install ntp\n\n// Start and enable the service\nsudo systemctl start ntpd \nsudo systemctl enable ntpd ",
      "language": "c",
      "name": "Fedora"
    }
  ]
}
[/block]

[block:api-header]
{
  "title": "8. Secure shared memory"
}
[/block]
Shared memory can be used in an attack against a running service, so it is always best to secure that portion of memory. You can do this by modifying the */etc/fstab* file.
[block:code]
{
  "codes": [
    {
      "code": "// First, you must open the file for editing\nsudo nano /etc/fstab\n\n// Next, add the following line to the bottom of that file:\ntmpfs /run/shm tmpfs defaults,noexec,nosuid 0 0",
      "language": "c",
      "name": "Ubuntu"
    },
    {
      "code": "// To do",
      "language": "c",
      "name": "Debian / CentOS / Fedora"
    }
  ]
}
[/block]

[block:api-header]
{
  "title": "9. Prevent IP spoofing"
}
[/block]
This one is quite simple and will go a long way to prevent your server's IP from being [spoofed](https://en.wikipedia.org/wiki/IP_address_spoofing). 
[block:code]
{
  "codes": [
    {
      "code": "// Open config file\nsudo nano /etc/host.conf\n\n// It will look like this:\n# The \"order\" line is only used by old versions of the C library.\norder hosts,bind\nmulti on\n\n// Change it to this:\n# The \"order\" line is only used by old versions of the C library.\norder bind,hosts\nnospoof on\n",
      "language": "c",
      "name": "Ubuntu"
    },
    {
      "code": "// To do",
      "language": "c",
      "name": "Debian / CentOS / Fedora"
    }
  ]
}
[/block]

[block:api-header]
{
  "title": "10. Harden the networking layer"
}
[/block]
There is a very simple way to prevent source routing of incoming packets (and log all malformed IPs) on your Ubuntu Server. Open a terminal window, issue the command *sudo nano /etc/sysctl.conf*, and uncomment or add the following lines:
[block:code]
{
  "codes": [
    {
      "code": "# IP Spoofing protection\nnet.ipv4.conf.all.rp_filter = 1\nnet.ipv4.conf.default.rp_filter = 1\n\n# Ignore ICMP broadcast requests\nnet.ipv4.icmp_echo_ignore_broadcasts = 1\n\n# Disable source packet routing\nnet.ipv4.conf.all.accept_source_route = 0\nnet.ipv6.conf.all.accept_source_route = 0 \nnet.ipv4.conf.default.accept_source_route = 0\nnet.ipv6.conf.default.accept_source_route = 0\n\n# Ignore send redirects\nnet.ipv4.conf.all.send_redirects = 0\nnet.ipv4.conf.default.send_redirects = 0\n\n# Block SYN attacks\nnet.ipv4.tcp_syncookies = 1\nnet.ipv4.tcp_max_syn_backlog = 2048\nnet.ipv4.tcp_synack_retries = 2\nnet.ipv4.tcp_syn_retries = 5\n\n# Log Martians\nnet.ipv4.conf.all.log_martians = 1\nnet.ipv4.icmp_ignore_bogus_error_responses = 1\n\n# Ignore ICMP redirects\nnet.ipv4.conf.all.accept_redirects = 0\nnet.ipv6.conf.all.accept_redirects = 0\nnet.ipv4.conf.default.accept_redirects = 0 \nnet.ipv6.conf.default.accept_redirects = 0\n\n# Ignore Directed pings\nnet.ipv4.icmp_echo_ignore_all = 1",
      "language": "c",
      "name": "Ubuntu"
    },
    {
      "code": "// To do",
      "language": "c",
      "name": "Debian / CentOS / Fedora"
    }
  ]
}
[/block]

[block:api-header]
{
  "title": "11. DDoS Protection"
}
[/block]
Servers that have a masternode hosted will be targets of automatic DDoS attacks from owners of other masternodes that want to increase their profits at the expense of shutting down or restarting the servers of their competition.

This configuration will allow you to avoid the most basic and common attacks, but even so, it is recommended to have a server that comes with some type of protection or mitigation service for DDoS attacks.

The following instructions are going to be added to the UFW rules, so I hope you followed the instructions to install and configure it.
[block:code]
{
  "codes": [
    {
      "code": "// Edit the UFW rules file\nsudo nano /etc/ufw/before.rules\n\n// Add those lines after *filter near the beginning of the file\n:ufw-http - [0:0]\n:ufw-http-logdrop - [0:0]\n\n// Add these lines near the end of the file, before the COMMIT\n### Start HTTP ###\n\n# Enter rule\n-A ufw-before-input -p tcp --dport 80 -j ufw-http\n-A ufw-before-input -p tcp --dport 443 -j ufw-http\n\n# Limit connections per Class C\n-A ufw-http -p tcp --syn -m connlimit --connlimit-above 50 --connlimit-mask 24 -j ufw-http-logdrop\n\n# Limit connections per IP\n-A ufw-http -m state --state NEW -m recent --name conn_per_ip --set\n-A ufw-http -m state --state NEW -m recent --name conn_per_ip --update --seconds 10 --hitcount 20 -j ufw-http-logdrop\n\n# Limit packets per IP\n-A ufw-http -m recent --name pack_per_ip --set\n-A ufw-http -m recent --name pack_per_ip --update --seconds 1 --hitcount 20 -j ufw-http-logdrop\n\n# Finally accept\n-A ufw-http -j ACCEPT\n\n# Log\n-A ufw-http-logdrop -m limit --limit 3/min --limit-burst 10 -j LOG --log-prefix \"[UFW HTTP DROP] \"\n-A ufw-http-logdrop -j DROP\n\n### End HTTP ###\n\n# Prevent ping flood\n-A INPUT -p icmp -m limit --limit 6/s --limit-burst 1 -j ACCEPT\n-A INPUT -p icmp -j DROP\n  \n  \n// Now close the file. \n// Before reloading all the rules, you need to make sure IPv6 is disable:\nsudo nano /etc/default/ufw\n  \n// Change the setting to no. The line should be at the beginning.\nIPV6=no\n  \n// Make sure UFW runs and reload everything:\nsudo ufw reload\n  ",
      "language": "c",
      "name": "Ubuntu"
    },
    {
      "code": "// To do",
      "language": "c",
      "name": "Debian / CentOS / Fedora"
    }
  ]
}
[/block]

[block:api-header]
{
  "title": "12. References"
}
[/block]
- [Digital Ocean - 7 Security Measures to Protect your Servers](https://www.digitalocean.com/community/tutorials/7-security-measures-to-protect-your-servers)
- [Securing a Server with Ansible](https://ryaneschinger.com/blog/securing-a-server-with-ansible/)
- [Tech Republic - How to harden ubuntu server 16-04 security in five steps](http://www.techrepublic.com/article/how-to-harden-ubuntu-server-16-04-security-in-five-steps/)
- [How to configure Auto-Updates on Linux Ubuntu Servers](http://www.zartl.info/?p=422)
- [Linode - Securing your Server](https://www.linode.com/docs/security/securing-your-server)
- [Rackspace - Linux Server Security Best Practices](https://support.rackspace.com/how-to/linux-server-security-best-practices/)
- [Best practices for SSH configuration](https://support.asperasoft.com/hc/en-us/articles/221494788-Best-practices-for-SSH-configuration)
- [Protect Ddos Attacks](http://bookofzeus.com/harden-ubuntu/hardening/protect-ddos-attacks/)