---
title: "Quick masternode installation video"
excerpt: "Slimmed down version of the full masternode install guide"
---
We have adapted the well-known Nodemaster install script for use with Helium. Nodemaster offers a relatively simple and automated way to set up one or more Masternodes on a single VPS (IPv6).

The link for the script is here (including a guide):

[https://github.com/heliumchain/vps](https://github.com/heliumchain/vps)

AKcryptoGUY made a video tutorial and accompanying text guide on installing multiple Masternodes with Nodemaster.  This version is the slimmed down version which removes several of the security hardening elements and should be easier to use by non-techies.

[https://medium.com/@AKcryptoGUY/quickly-install-multiple-helium-masternodes-on-vps-at-vultr-b508483b4de5](https://medium.com/@AKcryptoGUY/quickly-install-multiple-helium-masternodes-on-vps-at-vultr-b508483b4de5) 

If you find his guide or video helpful, please consider supporting his contributions by using his referral link to create your Vultr hosting account: [https://www.vultr.com/?ref=7568060](https://www.vultr.com/?ref=7568060) 

[block:embed]
{
  "html": "<iframe class=\"embedly-embed\" src=\"//cdn.embedly.com/widgets/media.html?src=https%3A%2F%2Fwww.youtube.com%2Fembed%2FbUdkKnH_Xqk%3Ffeature%3Doembed&url=http%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3DbUdkKnH_Xqk&image=https%3A%2F%2Fi.ytimg.com%2Fvi%2FbUdkKnH_Xqk%2Fhqdefault.jpg&key=f2aa6fc3595946d0afc3d76cbbd25dc3&type=text%2Fhtml&schema=youtube\" width=\"854\" height=\"480\" scrolling=\"no\" frameborder=\"0\" allow=\"autoplay; fullscreen\" allowfullscreen=\"true\"></iframe>",
  "url": "https://www.youtube.com/watch?v=bUdkKnH_Xqk&feature=youtu.be",
  "title": "Multiple Helium Masternod Setup on Vultr VPS, Slim Edition",
  "favicon": "https://s.ytimg.com/yts/img/favicon-vfl8qSV2F.ico",
  "image": "https://i.ytimg.com/vi/bUdkKnH_Xqk/hqdefault.jpg"
}
[/block]