---
title: "How to check if my Helium wallet is in the correct chain?"
excerpt: ""
---
There is a possibility that your wallet may be not synced up with the network properly or that your wallet may have somehow forked and isn't connected to the main network. Just to make sure that you are on the right block and is on the right network, please perform the following check:

1.  From your wallet's debug console (Tools -> Debug console or just use ./helium-cli getinfo in linux), type:  
`getinfo`

2.  Note the block number. ("blocks":) That is the block number that your wallet is currently synced up to.  
      
3.  Now type `getblockhash xxxxxx` (where xxxxxx is the block number you got from _getinfo_ output above)  

4.  Compare the hash to the block explorer's block hash for that same block via [https://www.heliumchain.info](https://www.heliumchain.info)  (search the block number that you have used in step 2 & 3)  
      
5.  If the hash is different, you are not on the right chain. Update to the [latest wallet](https://github.com/heliumchain/helium/releases) (if not already on it), restart the wallet, wait until wallet is synced, and follow steps 1 through 4 again.  
      
6.  If you are still not matching block:hash of the Helium block explorer, then perform a reindex.  
    Qt Wallet = Tools -> Wallet Repair -> Rebuild Index (this can take many minutes to complete)  
    Linux = Close wallet. Start the wallet with `-reindex` (e.g. `./heliumd -reindex`)  
    
7.  If that still fails, follow the next steps: 

	-GUI Wallet users:
	"Tools > Wallet Repair > Delete Local Blockchain Folders (-resync)" to initiate the full re-sync (unless you have a known good backup of the blockchain that you know how to restore).

	-Command line users:
	You can initiate the full resync during daemon startup with the command switch `heliumd -resync`
	
	Now re-launch the wallet and wait for it to sync. This can take a few hours on a slow internet connection.
	****Please note that during the sync your balance will show as 0 until near the end, this is normal****
    
8.  If the hash matched up between your wallet and the block explorer, then your wallet is on the right network.  
    
9.  If your recipient still hasn't received your coins, you need to ensure that the recipient is also on the right network and synced up to the latest block with no delays.