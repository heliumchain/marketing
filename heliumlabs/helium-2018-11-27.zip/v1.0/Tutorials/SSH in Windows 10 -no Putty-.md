---
title: "SSH in Windows 10 (no Putty)"
excerpt: ""
---
Windows 10 has added an option to connect with SSH to your remote server from the command line. This means Windows 10 users do not need to install [Putty](http://www.putty.org/) or any other 3rd party software anymore. It isn't a standard feature however so it needs to be enabled first. You can read a guide here:

[https://www.howtogeek.com/336775/how-to-enable-and-use-windows-10s-built-in-ssh-commands](https://www.howtogeek.com/336775/how-to-enable-and-use-windows-10s-built-in-ssh-commands/)

This is a video tutorial on enabling OpenSSH:
[block:embed]
{
  "html": "<iframe class=\"embedly-embed\" src=\"//cdn.embedly.com/widgets/media.html?src=https%3A%2F%2Fwww.youtube.com%2Fembed%2FxIfzZXHaCzQ%3Ffeature%3Doembed&url=http%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3DxIfzZXHaCzQ&image=https%3A%2F%2Fi.ytimg.com%2Fvi%2FxIfzZXHaCzQ%2Fhqdefault.jpg&key=f2aa6fc3595946d0afc3d76cbbd25dc3&type=text%2Fhtml&schema=youtube\" width=\"854\" height=\"480\" scrolling=\"no\" frameborder=\"0\" allowfullscreen></iframe>",
  "url": "https://www.youtube.com/watch?v=xIfzZXHaCzQ",
  "title": "How to enable and install Built-in SSH in Windows 10 using the windows command prompt or powershell",
  "favicon": "https://s.ytimg.com/yts/img/favicon-vfl8qSV2F.ico",
  "image": "https://i.ytimg.com/vi/xIfzZXHaCzQ/hqdefault.jpg"
}
[/block]
If you don't find OpenSSH in the list of features: make sure developer mode is enabled:
[
https://docs.microsoft.com/en-us/windows/uwp/get-started/enable-your-device-for-development](https://docs.microsoft.com/en-us/windows/uwp/get-started/enable-your-device-for-development)

 This is a video tutorial on enabling Windows 10 developer mode:
[block:embed]
{
  "html": "<iframe class=\"embedly-embed\" src=\"//cdn.embedly.com/widgets/media.html?src=https%3A%2F%2Fwww.youtube.com%2Fembed%2Fayo4pefuYAY%3Ffeature%3Doembed&url=http%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3Dayo4pefuYAY&image=https%3A%2F%2Fi.ytimg.com%2Fvi%2Fayo4pefuYAY%2Fhqdefault.jpg&key=f2aa6fc3595946d0afc3d76cbbd25dc3&type=text%2Fhtml&schema=youtube\" width=\"854\" height=\"480\" scrolling=\"no\" frameborder=\"0\" allowfullscreen></iframe>",
  "url": "https://www.youtube.com/watch?v=ayo4pefuYAY",
  "title": "How to enable developer mode windows 10",
  "favicon": "https://s.ytimg.com/yts/img/favicon-vfl8qSV2F.ico",
  "image": "https://i.ytimg.com/vi/ayo4pefuYAY/hqdefault.jpg"
}
[/block]

[block:api-header]
{
  "type": "basic",
  "title": ""
}
[/block]