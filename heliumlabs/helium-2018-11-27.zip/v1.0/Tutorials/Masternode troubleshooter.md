---
title: "Masternode troubleshooter"
excerpt: ""
---
The Helium wallet allows you to run the essential Masternode commands from the GUI on the **Masternodes** tab. However, if things aren't working as they should, the easiest way to diagnose the problems is through the command line. You can follow the below steps to see if everything is set up and working correctly. 

Note that it can currently take up to a day for your masternode to start earning rewards. As the network grows so will the waiting time. If the first two commands below return the desired result: just wait a bit more. Before you make changes in the **.conf** files of your VPS, always stop the client first. After you make changes in your local **.conf** files, always restart your wallet afterwards.

If you installed using Nodemaster: the commands there are slightly different. Preclude every command with `sudo /usr/local/bin/helium-cli -conf=/etc/masternodes/helium_n1.conf`where `n1` is the nr. of your masternode. So `helium-cli masternode status` becomes `sudo /usr/local/bin/helium-cli -conf=/etc/masternodes/helium_n1.conf  masternode status` etcetera.

<br>
* On your controller wallet, enter <code>masternode list-conf</code> in the debug console. Make sure the status of your masternode is enabled/active. Sample output:

 <code>"alias": "nodealias1",
"address": "XX.XX.XX.XX:9009",
"privateKey": "7ABCDFEGHIJKLMNOPQRSTUVWZYX",
"txHash": "adb0fc2cce59b891852b3057dfe196d318fd3e97de3bdde4deff7d7c82a3eb0b",
"outputIndex": "0",
"status": "ENABLED"
</code>
<br>

* On your Masternode wallet (your VPS), enter <code>helium-cli masternode status</code> and check that it returns <code>Masternode succesfully started</code>.  Also make sure the <code>addr</code> entry matches the receiving address that holds your 1000 HLM collateral. Sample output:

  <code>"txhash":
"adb0fc2cce59b891852b3057dfe196d318fd3e97de3bdde4deff7d7c82a3eb0b",
"outputidx": 0,
"netaddr": "XX.XX.XX.XX:9009",
"addr": "SABCDEFGHJKLMNOPQRSTUVWZYX",
"status": 4,
"message": "Masternode successfully started"</code>
<br>

If the above commands returned the desired result: great. All is working as should be and all you have to do is wait. If not, continue below.

* Still on your Masternode wallet enter <code>helium-cli getblockcount</code> and make sure it matches the block count of your wallet and that of the blockexplorer. If it doesn't. Stop your masternode with <code>helium-cli stop</code> and restart and resync it with <code>sudo heliumd -daemon -resync</code>.
<br>

* On your controller wallet, open the **masternode.conf** file. Make sure the txhash matches the one in the <code>helium-cli masternode status</code> output of your Masternode wallet. Also check that the IP address matches the address of your VPS. The txhash is the brown entry in this **masternode.conf** example:

<code><span style="color:black">MN1</span>
<span style="color:red">31.14.135.27:9009</span>
<span style="color:green">892WPpkqbr7sr6Si4fdsfssjjapuFzAXwETCrpPJubnrmU6aKzh</span>
<span style="color:brown">8ba8caae2670bb38d43fb609e31a337d4d7b4fd4544f93b8cc3b8b3426409</span>
<span style="color:blue">0</span></code>
<br>

* On your Masternode wallet, open the **helium.conf** file with <code>sudo nano ~/.helium/helium.conf</code> and check that the <code>masternodeprivkey</code> entry matches the one in the **masternode.conf** file of your controller wallet. This is the green entry in the above example. The masternodeprivkey is the key you generated in the controller wallet with the <code>masternode genkey</code> command.
<br>

* Check the <code>masternode list</code> output of both your controller and Masternode wallets  (your masternode should on the bottom of the list somewhere). See that the txhashes of both match. 
<br>

**Notes**

The above troubleshooter assumes you either installed Helium from source or copied the files to <code>/usr/local/bin/</code> on your VPS. If you didn't, you will have to find the folder where the files are (usually in <code>~/helium-0.15.2/bin/</code>) and issue every command with <code>./</code>. So <code>helium-cli masternode status</code> becomes <code>./helium-cli masternode status</code>.