---
title: "Masternode setup guide (VPS)"
excerpt: ""
---
[block:callout]
{
  "type": "warning",
  "body": "There is the [Nodemaster script](https://www.heliumlabs.org/v1.0/docs/installing-masternodes-with-nodemaster) that automates deployment to a large degree and is especially useful if you want to set up multiple masternodes in one server. This guide is for those who want to understand more details about the technical side of things.",
  "title": "Disclaimer"
}
[/block]
This is a guide for setting up a Helium masternode using the so called *hot-cold* set up. We will use a VPS with Ubuntu 16.04 for the remote masternode while keeping the collateral coins safely in your local wallet. You *can* set a masternode up on your local machine but this is less convenient, less economical and less secure, and therefor not recommended. This guide was written using a 1GB Ubuntu 16.04 VPS on IPv4.

You can of course also use an install script or have a 3rd party host your node (see **Resources** at the bottom of this guide) but doing it yourself is fun and teaches you a lot about what's going on.

##** Step 1: prepare your local wallet**


For the purpose of this guide we'll assume you downloaded the Helium wallet from an official source (website, github or OP on bitcointalk) and succesfully installed it. Find a guide on how to do this here: link TBA

A Helium masternode requires 1000 coins as collateral. These coins need to be in a single transaction for it to work. In your local wallet, click **Tools** and click **Debug Console**.

In the Debug console, enter <code>masternode genkey</code> and it will return, for example:

<code>892WPpkqbr7sr6Si4fdsfssjjapuFzAXwETCrpPJubnrmU6aKzh</code>.

This is your masternodeprivkey and you will need this later. So save it.

Still in the debug console enter <code>getaccountaddress "masternode_alias"</code> You can replace <code>"masternode_alias"</code> with anything you like. I'll call mine **MN1** for the purpose of this tutorial.  So: <code>getaccountaddress MN1</code>, in my case, returns: <code>SNWvmLg8rn5wCmPCed7LwaCN5iKAiTye2J</code> and that is the collateral address for my masternode.

Now we'll need to send exactly 1000 Helium to the address we just created. If you are withdrawing from an exchange, make sure to take any fees into account. This transaction will some confirmations before we can continue so we'll use that time to set up our VPS.

##** Step 2: prepare the VPS and install the software**

For the purpose of this guide we'll also assume you'll figure out how to make an account with a VPS provider such as DigitalOcean, Linode or Vultr. You will not need anything fancy. A 1GB VPS with Ubuntu 16.04 will do the trick. If your VPS provider allows you to set up SSH keys with installing, do it. SSH login is far more secure and convenient than using a password. 

If you do use a root password. **Make sure it is long and random**. A 24 character password from [random.org](https://www.random.org/passwords/) does the trick. If you don't set a difficult password your VPS will be hacked within hours and added to a botnet. While nobody can steal your coins your VPS will be used for all kinds of nefarious activities and you'll run into a bill for excess bandwidth from your VPS provider.

Check Slack for referral links for free credit with VPS providers.

Now that your VPS is on line you'll need to access it. For Linux and Mac users this can be done through the terminal. Windows users need [Putty](https://www.putty.org/), [enable an extra feature in Windows](https://www.heliumlabs.org/docs/ssh-in-windows-10-no-more-putty) or [another SSH client.](https://www.slant.co/topics/149/~best-ssh-clients-for-windows)

Assuming you successfully logged in to your VPS we'll first make sure everything is up to date, make a new user, double check, set up the firewall and add some virtual memory. 

Update everything:

<code>apt-get update -y && apt-get upgrade -y</code>

Add a new user, give it privileges and change user. Choose your own username and set a secure password. You can accept defaults and confirm with **y**:

<code>adduser bruno</code>
<code>adduser bruno sudo</code>
<code>su bruno</code>
<code>cd</code>

Make sure <code>git</code>, <code>autogen</code> and <code>ssh</code> are installed:

<code>sudo apt-get install git autogen openssh-server -y</code>

Set up the firewall and answer **y** at the prompt:

<code>sudo ufw default allow outgoing</code>
<code>sudo ufw default deny incoming</code>
<code>sudo ufw allow 9009</code>
<code>sudo ufw allow 22</code>
<code>sudo ufw enable</code>

Add virtual memory (only needed on a <2GB VPS):

<code>sudo fallocate -l 2G /swapfile</code>
<code>sudo chmod 600 /swapfile</code>
<code>sudo mkswap /swapfile</code>
<code>sudo swapon /swapfile</code>
<code>echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab</code>

Your VPS is now ready and secure. However, there are a lot more things you can do to harden it and make it more resistant to DDOS attempts. [ Check RzeroD's guide on how to do that here.](https://www.heliumlabs.org/docs/how-to-harden-a-new-linux-vps)

There are two ways to install Helium. By building it from source (**A**) or by downloading the binaries (**B**). Choose either one. 

**A**: Build Helium from source 

<code>sudo git clone https://github.com/heliumchain/helium</code>
<code>cd helium/</code>
<code>sudo add-apt-repository ppa:bitcoin/bitcoin -y</code>
<code>sudo apt-get update</code>

<code>sudo apt-get install build-essential libtool automake autotools-dev autoconf pkg-config libssl-dev libevent-dev libboost-all-dev libprotobuf-dev protobuf-compiler libdb4.8-dev libdb4.8++\-dev -y</code>

<code>sudo ./autogen.sh</code>
<code>sudo ./configure  --disable-tests --with-unsupported-ssl</code>
<code>sudo make</code>
<code>sudo make install</code>

The <code>sudo make</code> part can take up to half an hour. If you are installing on a multi-core machine you can try <code>sudo make -j4</code> (for 4 cores) instead which will significantly speed everything up. You can continue with step 3 while it is working as long as you **don't forget** to run the <code>sudo make install</code> command before you proceed to step 4. Else just grab a coffee and wait for it to finish.

**B**: Download the binaries:

<code>wget https://github.com/heliumchain/helium/releases/download/v0.15.2/helium-0.15.2-x86_64-linux-gnu.tar.gz
tar zxvf helium-0.15.2-x86_64-linux-gnu.tar.gz
sudo cp -r ~/helium-0.15.2/bin/. /usr/local/bin/</code>

##** Step 3: configure your local wallet**


For your masternode to communicate with your wallet and vice versa we will need to make some changes to their respective configuration files. 

We'll assume you still have your local wallet open and by now the 1000 Helium transaction we made earlier should have enough confirmations.

Open your **Debug console** and enter:

<code>masternode outputs</code>

The return will look like this:

<code>"txhash": "8ba8caae2670bb38d43fb609e31a337d4d7b4fd4544f93b8cc3b8b3426409",
"outputidx": 0</code>

We will need these two values so save them.

Now open the <code>masternode.conf</code> file in a text editor. It is located in the client's data directory:

Linux: <code>~/.helium</code>
OSX: <code>~/Library/Application Support/Helium</code> or <code>~/.helium</code>
Win: <code>%Appdata%/Helium</code>

You can also edit it through the client. Click **Tools** then **Open Masternode Configuration File**

There is an example in there which you can remove. Everything should be on a single line and the file should be made to look *exactly* like this:

<code><span style="color:black">MN1</span> <span style="color:red">31.14.135.27:9009</span> <span style="color:green">892WPpkqbr7sr6Si4fdsfssjjapuFzAXwETCrpPJubnrmU6aKzh</span> <span style="color:brown">8ba8caae2670bb38d43fb609e31a337d4d7b4fd4544f93b8cc3b8b3426409</span> <span style="color:blue">0</span></code>

-<span style="color:black">The name (masternode_alias) you gave your masternode</span></code>
-<span style="color:red">The IP and port of the VPS</span>
-<span style="color:green">The masternodeprivkey from step 1</span>
-<span style="color:brown">The first value from <code>masternode outputs</code></span>
-<span style="color:blue">The second value from <code>masternode outputs</span></code>

So: 

<code><masternode_alias> <VPS_ip_adress:port> <masternodeprivkey> <txhash> <outputidx></code>

Save the file and open the <code>helium.conf</code> file which is conveniently located in the same folder. You can also open it from the client by clicking **Tools** and **Open Wallet Configuration File**.

Make it look like this:

<code>rpcuser=long random username</code> 
<code>rpcpassword=longer random password</code> 
<code>rpcallowip=127.0.0.1</code>
<code>listen=0</code>
<code>server=1</code>
<code>daemon=1</code>
<code>logtimestamps=1</code>
<code>maxconnections=256</code>

Save this file too. Close your client and restart it. 

## **Step 4: configure the masternode**


Assuming the <code>sudo make</code> and <code>sudo make install</code> from step 2 were succesful, we will now change the <code>helium.conf</code> file on the masternode as well. On your VPS, enter: 

<code>sudo mkdir ~/.helium</code>
<code>cd ~/.helium</code>
<code>sudo nano helium.conf</code>

This will bring up a text editor. Make the file look like this:

<code>rpcuser=long random username</code>
<code>rpcpassword=long random password</code>
<code>rpcallowip=127.0.0.1</code>
<code>listen=1</code>
<code>server=1</code>
<code>daemon=1</code>
<code>logtimestamps=1</code>
<code>maxconnections=256</code>
<code>masternode=1</code>
<code>externalip=31.14.135.27</code>          
<code>bind=31.14.135.27</code>                
<code>masternodeaddr=31.14.135.27:9009</code> 
<code>masternodeprivkey=892WPpkqbr7sr6Si4fdsfssjjapuFzAXwETCrpPJubnrmU6aKzh</code>

Change the IP addresses after <code>externalip=</code> ,<code>bind=</code> and <code>masternodeaddr=</code> to the IP of your VPS. Change the value after <code>masternodeprivkey=</code> to your own masternodeprivkey from step 1.
This guide assumes your masternode is directly internet facing. If it is behind a router the IP after <code>bind=</code> should be the internal IP.

Press **Ctrl+X** to exit and press **y** and **Enter** to save.

## **Step 5: start the masternode**

We'll now start up the Helium client on the VPS and start the masternode:

<code>sudo heliumd -daemon</code>

This will start the client. Give it a minute to boot up properly before checking if its working:

<code>helium-cli getinfo</code>

This will return a long list of random information. Before continuing we need to make sure we are synced so check if the value of <code>blocks:</code> (blockheight) is the same as in your wallet. If it isn't: wait.

When the masternode is properly synced on the VPS. leave it open and go to your local wallet. Make sure your wallet is unlocked. Click the **Masternodes** tab and click **Start alias**. Click **Yes** on the pop-up and another pop-up will appear that says <code>Sucessfully started masternode.</code>, in the overview you'll see <code>status: ENABLED</code>

To make sure we'll check on the masternode itself too. On your VPS, enter:

<code>./helium-cli masternode status</code>

This should return something along the lines of:

<code>{
“txhash” : “8ba8caae2670bb38d43fb609e31a337d4d7b4fd4544f93b8cc3b8b3426409”,
“outputidx” : 0,
“netaddr” : “31.14.135.27:9009”,
“addr” : “DSNWvmLg8rn5wCmPCed7LwaCN5iKAiTye2J”,
“status” : 4,
“message” : “Masternode successfully started”
}</code>

If all of this worked: awesome. 

If it didn't: join us in #masternodes and we will help you fix it.

## **I did something wrong and now I'm confused**

At pretty much any point in this tutorial you can retrace your steps. If all else fails: `reboot` will restart your VPS. You can log back in after a few minutes and with `su USERNAME` and `cd` you'll be in the home directory and you can pick up from there. 


## **Multiple masternodes**


You can set up multiple remote masternodes using the same local controller wallet. The steps for every extra masternode are virtually identical to what is described above.

For every new masternode you will to make a new collateral address with <code>getaccountaddress</code> and make a new masternodeprivkey with <code>masternode genkey</code>

After you send the next 1000 HLM to your new collateral address you will notice that <code>masternode outputs</code> now shows a list. The most recent output should be on top so just pick the <code>txhash</code> and <code>outputidx</code> that you haven't already used.

For every masternode make a new entry on a new line in <code>masternode.conf</code>

You will see every masternode you create this way show up in the **Masternodes** tab.

When making multiple 1000HLM transactions to yourself to serve as collateral. The wallet might reuse the one transaction to make the next. You can prevent this from happening by either setting up the nodes 1 by 1 or by locking the coins in coin control:

**Settings**>**Options**>**Wallet**>**Enable coin control features**. Access it under the **Send** tab

## **Stop the masternode**


The 1000 Helium used as collateral for your masternode is locked by the wallet. You can still make transactions from the wallet but it will not let you send the 1000 Helium used as collateral.

To stop your masternode (and unlock the coins) login to your VPS. Change user, go to your Helium folder with <code>cd</code> and <code>cd ~/helium/src</code>  and stop the masternode with <code>./helium-cli stop</code>. Then, on your local machine, open the <code>masternode.conf</code> file, empty it, and save it. After you restart the wallet your coins will be available.

##**Testnet**

You can use this guide to set up a masternode on testnet also. But there are a few minor things that need to be changed.

Add <code>testnet=1</code> to both the local helium.conf file and the remote helium.conf file. Also, use port 19009 (testnet port) rather than 9009 (mainnet port) when configuring the firewall on the VPS and in the local and remote <code>helium.conf</code> files.

On your local machine: use the <code>masternode.conf</code> file located in the <code>/testnet4</code> folder in your data directory rather than the 'normal' one.

## **Resources**

Helium website: www.heliumchain.org

Community website: www.heliumlabs.org

Helium community on Discord:  TBA (#help for technical support)

Since most Dash/PIVX based masternodes work more or less the same you can find answers to common questions, problems and errors by googling. Please do this first before asking for help :)

Cryptotron's install script for Helium masternodes: https://github.com/cryptotronxyz/heliumnode

Nodemaster install script for Helium masternodes (allows multiple nodes on single VPS with IPv6): [https://github.com/heliumchain/vps](https://github.com/heliumchain/vps) (with big thanks to Moonshot)

3rd party Helium masternode hosting providers: https://nodesupply.com, https://www.node-vps.com and [www.manohosting.com](http://www.manohosting.com) offer hosted Masternodes for Helium

Helium github: https://github.com/heliumchain/helium

The [Digital Ocean Community](https://https://www.digitalocean.com/community) has an enormous amount of information and tutorials regarding VPS' and Ubuntu in general. 

@RzeroD was kind enough to write a comprehensive guide for hardening Linux servers. [You can find it here.](https://www.heliumlabs.org/docs/how-to-harden-a-new-linux-vps) If someone wants to take out your masternode they will. But the harder you make it the more likely it is they'll pick a easy target instead.