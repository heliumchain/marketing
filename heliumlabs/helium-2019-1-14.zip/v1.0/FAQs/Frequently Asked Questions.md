---
title: "Frequently Asked Questions"
excerpt: ""
---
**Welcome to the Helium FAQ**

**We've released a wallet update: [https://github.com/heliumchain/helium/releases/tag/v0.16.0](https://github.com/heliumchain/helium/releases/tag/v0.16.0) .This update introduces a voting GUI and fixes a staking error. It is not mandatory but we recommend you update regardless.

**Make sure you are running [at LEAST version 0.15.2](https://github.com/heliumchain/helium/releases). This was a mandatory update. If you are experiencing issues after updating, [make sure to check out the update guide](https://www.heliumlabs.org/v1.0/docs/masternodewallet-update-guide).**

**Due to its various imperfections we are phasing out the Slack. Please join our discord in https://discord.gg/9Evn2zT. If you keep files or important stuff in the Slack we suggest you retrieve them.**

This FAQ was last updated on January 7th, 2019


#Safety awareness

1. Never browse without ad blockers. [Ublock Origin](https://en.wikipedia.org/wiki/UBlock_Origin) and [Disconnect](https://disconnect.me/) are a star team. Block Javascript. Different solutions will do also but just make sure you block it **all**.

2. Never click links. Only use bookmarks or type in the URL yourself. [Don't be spoofed.](http://www.businessinsider.com/scammers-spoofing-cryptocurrency-exchange-site-urls-incredibly-hard-to-spot-2018-2#usually-you-can-tell-if-a-website-isnt-legitimate-if-it-doesnt-have-the-green-https-that-comes-before-a-websites-url-1)

3. Separate your accounts. Use one email address for exchanges. Use a different one for forums, airdrops etc. Keep your personal email personal. ([protonmail is awesome](https://protonmail.com/))

4. Make back ups of everything, and back up your back ups. Hardware wallets rock. [Encrypted USBs also do the trick](https://technet.microsoft.com/en-us/library/ff404223.aspx).

5. A back-up wallet.dat is susceptible to forgotten passwords and [Cosmic Death Rays](https://en.wikipedia.org/wiki/Soft_error#Cosmic_rays_creating_energetic_neutrons_and_protons). Also back up the private keys.

6. Turn on 2FA for all important accounts. Back up the codes. Cryptopia's PIN code is **NOT** safe. If you click a phishing link with this turned on you will still lose your money. Use Google Authenticator, Authy or email 2fa. [2fa by SMS is not safe](https://www.howtogeek.com/310418/why-you-shouldnt-use-sms-for-two-factor-authentication/).

7. Never download wallet files from anywhere other than trusted sources like the github or the OP on Bitcointalk. Run any downloaded wallet files through an aggregated antivirus engine such as [www.virustotal.com](http://www.virustotal.com) first to be 100% sure.

8. Do not re-use passwords and don't make them up yourself. Use [random passwords](https://www.random.org/passwords/) and a [password manager](https://www.tomsguide.com/us/best-password-managers,review-3785.html) to keep track of it all. If you do want to memorize: [here's how to do it.](https://xkcd.com/936/)

9. No, Steve won't be giving away Helium on Twitter.

10. **Encrypt your wallet**.

# Important Links

- [Homepage](www.heliumchain.org)
- [Github](https://github.com/heliumchain/helium)
- [Guides and tutorials](https://www.heliumlabs.org/docs/)

- [Blockexplorer 1](https://www.heliumchain.info)
- [Blockexplorer 2](https://www.heliumstats.online)
- [Initial announcement on BitcoinTalk](https://bitcointalk.org/index.php?topic=1809278.0)

- [Discord](https://discord.gg/9Evn2zT)
- [Telegram](https://t.me/HeliumChain)

- [Slack archives](https://slarck.com/v2d0Ku/)

- [Community forums](https://heliumcha.in/)
- [Helium News](https://goo.gl/forms/8flzE0N8mYppcKDE3)  (Mailing list)
- [Whitepaper](http://www.heliumpay.com/img/WhitePaper.pdf)

# Governance

- [How to submit a proposal](https://www.heliumlabs.org/docs/how-to-create-a-budget-proposal)
- [How to vote on a proposal](https://www.heliumlabs.org/docs/how-to-vote-for-a-budget-proposal)
- [Proposal explorer](https://www.heliumstats.online/governance/)

# Community Links

- [Community forums](https://heliumcha.in/)
- [Korean community on Kakao](https://open.kakao.com/o/gTNCuoB)  (pm @tomato or @ky kim for the password)
- [Korean community on Naver.com](https://cafe.naver.com/heliumpay )
- [Russian community on VKontakte](http://google.com)

# Social Media

- [Twitter](https://twitter.com/heliumchain)
- [Facebook](https://web.facebook.com/HeliumChain.org/?_rdc=1&_rdr)
- [Reddit](https://www.reddit.com/r/heliumchain)

# Exchanges

- [Crex24](https://crex24.com/exchange/HLM-BTC)
- [Cryptopia](https://www.cryptopia.co.nz/Exchange?market=HLM_BTC)
- [Crypto Bridge](https://wallet.crypto-bridge.org/market/BRIDGE.HLM_BRIDGE.BTC)
- [Amsterdex](Amsterdex: https://amsterdex.com/exchange?market=hlm) 

# 3rd part services:

- [Node VPS hosting](https://www.node-vps.com)
- [Nodesupply hosting](https://nodesupply.com/)
- [Mano hosting](http://www.manohosting.com/web_page/index.php)

- [NodeValet masternode installation wizard](https://nodevalet.io)

- [Heliumstats masternode monitoring](http://heliumstats.online/mynodes/index.php) 
- [Masternodes Online masternode monitoring](https://masternodes.online/currencies/HLM/)
- [Nodecheck masternode monitoring](https://nodecheck.io/currency/HLM)

#Helium


##Parameters:

PoS
Initial supply: 8891432 (snapshot)
Block reward: 5. Reward decreases by 0.5 annually until it reaches a tail emission of 2
Reward structure: 50% PoS / 50% Masternodes. 
Governance subsidy: 7.2%
Masternode collateral: 1000
Block time: 1 minute
Port: 9009

The first 28000 blocks had a reduced reward of 0.2. This was done to make the launch as fair as possible.

##Where can I download the Helium wallet?

You can find the latest version of the Helium wallet on Github:

[https://www.github.com/heliumchain/helium/releases](https://www.github.com/heliumchain/helium/releases)

Never download wallets from any source other than the Github. Some antivirus scanners will give a false positive when installing the files. To make sure its all safe: use an online antivirus engine such as [VirusTotal](https://www.virustotal.com) to scan the files.

[This is a guide to installing and using the Helium wallet.](https://www.heliumlabs.org/docs/wallet-setup-and-staking-guide)

##Why PoS?

Read a bit more about why this direction was taken under [**Code base**](https://www.heliumlabs.org/docs/frequently-asked-questions#section-code-base)

## How can I claim my coins?

If you had your SPR on Cryptopia during the snapshot you'll already see them on your balance. If you had your coins on a local wallet during the snapshot you will have to [import your spreadcoin private key into the Helium wallet.](https://www.heliumlabs.org/docs/importing-a-spreadcoin-private-key) 

## What will the total supply be?

As a direct consequence of shifting to PoS there were some alterations made to total supply and emission rate. While a PoW coin can have a limited supply a PoS coin, by definition, can't. We tried to stick as close to the original numbers as possible. These are the theoretical numbers for the first 10 years:
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/f1fed11-stepped_supply_example.png",
        "stepped_supply_example.png",
        1236,
        298,
        "#eae9e8"
      ]
    }
  ]
}
[/block]
## Why no ICO? I want ERC20 tokens!

karmashark wrote:

>Many have asked why we are doing a coin redemption and a economic hard work / technical fork opposed to a straight ICO. This is a fair question and deserves an answer. Helium is not an ordinary project as it has deep ties dating back to DASH and more recently, Spreadcoin. The original plan was to make Spreadcoin into what Helium is going to be, a network of value utilizing both Master nodes and Service nodes. A plan was originally agreed upon to take Spreadcoin in this direction. Over time the lead developer on Spreadcoin brought forth a new vision which was not in alignment with the original plan - thus the economic fork of Spreadcoin and the technical fork of DASH. Since many of the previous members of Spreadcoin have come over to create Helium, we decided to keep as much of the old plan intact instead of starting over after several years of work. To understand the full history of Helium one must first read the Spreadcoin thread on BitcoinTalk.org, however here is a short summary on when and why we went in this direction:  [https://bitcointalk.org/index.php?topic=1045373.msg18030003#msg18030003](https://bitcointalk.org/index.php?topic=1045373.msg18030003#msg18030003)

## I'd like to add Helium to my platform, how to proceed?

Helium strongly encourages the development of 3rd party applications and therefor, for a limited time only, we're willing to waive the 500$ fee we normally charge exchanges, news outlets, masternode monitoring sites and other 3rd parties that want to integrate us into their platforms. To be eligible for this limited time offer: please contact a mod.

#Code base

## Why was PIVX chosen as the code base?

While the original plan was to stick with DASH code, the circumstances have changed over the last year. The DASH evolution update will be very big and it will not be easy for a 'small' project like Helium to easily implement those changes. Also, there is no reason to assume DASH will meet their target dates. This could mean that if Helium were to stick with DASH it could turn out to be a dead end road in a year from now. Out of several alternatives PIVX was chosen by the community as the most viable option since it doesn't suffer these issues and will allow Helium to implement its vision in the same way that DASH would.

## So Helium will use Proof of Stake, how does that work?

Here is a little explanation from the PIVX website: [https://pivx.org/reward-system/](https://pivx.org/reward-system/) Note that Helium will have its own parameters. Another good place to start is [Wikipedia](https://en.wikipedia.org/wiki/Proof-of-stake). 
For some more in depth information on POS [click here](https://en.bitcoin.it/wiki/Proof_of_Stake). or [here](https://github.com/ethereum/wiki/wiki/Proof-of-Stake-FAQ) 

## So there will be no mining?

No (apart from a short period low reward mining to kickstart the chain). Coin emission will take place through staking and masternode rewards. Since POS needs a sufficient % of coin supply actively staking to make sure the network is secure, and coins used as masternode collateral do not stake, it is important to balance the both.

50% of block rewards will go to Stakers and 50% of rewards will go to Masternodes. Since people will weigh the cost/reward of each when deciding whether to stake or run a Masternode, the network balances itself.

##Is PoS better than PoW?

This is as endless a discussion as McDonalds/Burger King or Sylvester Stallone/Jean Claude van Damme but an interesting one regardless. 

The PoS/PoW debate has been going on (with varying intensity) ever since Peercoin first implemented PoS in 2012. As with most debates in the crypto-space it is mainly fought out by fundamentalists on both sides of the spectrum and as such it is very hard to find an unbiased overview of all arguments.

Without going into detail it is safe to say that on a purely theoretical level PoW is probably more 'secure' than PoS but this does not tell the whole story. PoW coins do suffer from [mining economics](https://www.reddit.com/r/btc/comments/7cibdx/the_flippening_explained_how_bch_will_take_over/), [hardware monopolies](https://www.antbleed.com/), multipool attacks* or [bad code](https://bitcointalk.org/index.php?topic=3256693.0) to name a few. These are all externalities that tend to be overlooked when discussing the matter on a purely theoretical level. 

Having said that; it is always good to realize the potential weaknesses of ones consensus algorithm so a good start is to [read up on some valid criticism from a PoW advocate](https://medium.com/@hugonguyen/proof-of-stake-the-wrong-engineering-mindset-15e641ab65a2).

It is important to realize that Helium's decision to go with PoS wasn't an ideological decision but a practical one. 

*A multipool aims to always mine the most profitable coin and switches from coin to coin according to profitability. For smaller coins (and especially ASIC algorithms) this means that at any given time an unholy amount of hashpower can be directed towards their network. Multipools tend to 'slash and burn'. They mine low difficulty blocks and go elsewhere once the difficulty gets to high, leaving the affected coin with high difficulty blocks and no hashrate to solve them. 

##Now that I've read all that, will the network be safe?

It probably will be. PIVX seems to be doing pretty well and there are plenty of other POS coins out there that have successfully averted "impending disaster". There is renewed interest in PoS as of recently and you can expect all kinds of cool new ways of making PoS even more secure to emerge in the near future.

# Masternodes

## How much HLM do I need for a Masternode?

1000 HLM.

## Now that we'll use PoS, will this still be profitable?

Yes, if you look at current return on investment (emission rate) on DASH and PIVX masternodes you'll find that the reward percentage is more or less the same. Helium will initially have a higher emission rate than the aforementioned. Users will make a cost/return calculation when deciding to stake or run masternodes so you can expect the returns for each to be more or less balanced.

## What else will I need for a Masternode?

You'll need a VPS to host it on. You can of course host it on your home computer but a VPS is easier, safer and cheaper.

[Helium Masternode setup guide](https://www.heliumlabs.org/docs/masternode-setup-guide)

[Nodemaster install script for (bulk) Masternodes](www.github.com/trollboxteela/vps)

[Masternode troubleshooter](https://www.heliumlabs.org/docs/masternode-troubleshooter-1)

Alternatively you can opt for a hosted Masternode. These are a little less cost effective than doing it yourself but they make things very convenient. 

[https://nodesupply.com](https://nodesupply.com), [https://www.node-vps.com](https://www.node-vps.com) and [www.manohosting.com](http://www.manohosting.com) offer hosted Masternodes for Helium.

##Why is there no guide for running Masternodes on Windows?

Running a local Masternode on a Windows machine is less convenient (your machine needs to be online 24/7) and inherently unsafe. Keeping your collateral wallet on a Windows machine is perfectly safe but you should never have your collateral wallet and Masternode on the same machine. Especially not when it is Windows. The main reason for the hot-cold set up using a Linux VPS is security. For those that insist regardless: there was a guide posted [here](https://bitcointalk.org/index.php?topic=5056752.msg47383187#msg47383187).

## What are Servicenodes?

ServiceNodes will perform for profit related services. An Uber type model will be created where the network and users rate providers.

The initial focus will be for Service Nodes to run fast relay networks, called Decentralized Digital Services Networks (DSDN). These will enable anyone to run a full Bitcoin node for anyone else, for a fee. Or users can run their own secure Helium Nodes, Bitcoin nodes, Monero nodes, etc. Basically a cloud blockchain provider.

You can find more information in the original whitepaper:

[http://www.heliumpay.com/img/WhitePaper.pdf](http://www.heliumpay.com/img/WhitePaper.pdf)


## How much for a Servicenode?

It is undecided at this point, but devs have floated numbers between 5,000 HLM and 10,000 HLM. Devs have also stated that a service node may be priced as a flat rate in fiat, presumably so that the price remains somewhat fixed.

coins101 wrote:

>One of the things I want to avoid with Service Node is the barrier to entry on collateral. If we are asking you to buy a franchise, we can't also ask you to spend a lot of money on buying. 1,000 HLM right now it's relatively affordable, but what will happen in a few years time? 

>You'll be spending your working capital on buying the collateral and leaving you with little money to buy the franchise and then set-up your services.  

>That would potentially limit the numbers of people wanting to get involved. We do, however, need to have some collateral requirements. Perhaps this is the point at which we say that collateral for service nodes is flexible.

and:

>(...)one of my concerns is that we price out people who would otherwise be technically very good at running service nodes


# Snapshot

## When was the snapshot?

[Block number 1657200 at 8:12 PM UTC, 9th of October 2017.](https://chainz.cryptoid.info/spr/block.dws?80f6c62be9910cd3e245d071c8d3cc874bd035800411ddd506c13183370f612b.htm)

[This is the address-balance list of the snapshot.](https://github.com/heliumchain/helium/blob/master/contrib/sprledgerxfr/spr_addys_filtered.py)

Since the developers pruned the largest Bittrex wallet along with <10 SPR balances (out of practical consideration) from the distribution the above list is not the same as the initial SPR ledger. Everything was done in a completely transparent fashion however, so anyone can check what went down.

@gj (gjhiggins) did the development on the snapshot and the ledger transfer process. @gj was also kind enough to provide a very detailed and clear explanation of his work:

[https://gist.github.com/gjhiggins/692cf73c0f2b6bde406fc29f427777b0#file-spr-hlm-ledger-transfer-process-md](https://gist.github.com/gjhiggins/692cf73c0f2b6bde406fc29f427777b0#file-spr-hlm-ledger-transfer-process-md)

Accounts on Cryptopia have already been credited with a balance in Helium.

## I had my coins in a local wallet during the snapshot block, what will happen now?

Your balance has been recorded on the block that will be used for the distribution of Helium. As long as you have your private key there is no need to keep the coins in your wallet. You will be able to claim your Helium by importing your SPR keys.

## I was living under a rock during the snapshot and kept my SPR on Bittrex, what now?

Bittrex was originally approached for facilitating the snapshot but decided not to participate. They have also made it clear that they will not credit their users with the airdropped HLM. There is, unfortunately, nothing the team or community can do about this.

## How many SPR was on Bittrex at the time of the snapshot?

A preliminary estimate of the Bittrex wallets puts the amount at ~750k 

## So they'll get to keep that?

Ideally not. Through analyzing the SPR blockchain it is possible to identify a large part of Bittrex' SPR addresses. SInce the community consensus is that Bittrex should not receive airdrop coins the team removed them from the HLM distribution. 

The team did not remove all the addresses associated with Bittrex. Doing so would mean a risk of false positives occurring and people not receiving coins they're entitled to. The address removed is SdbyXf2f1xCy5zPQVgELigaZgMusvmJNuE with a balance of 432870 Helium.

## Is my Spreadcoin useless now?

Spreadcoin is a pretty fun coin and there are lots of cool things you can do with it. The Helium and Spreadcoin devs decided to part ways and each coin will be headed a different direction. For some more info on where SPR is going check their [bitcointalk topic](https://bitcointalk.org/index.php?topic=715435.0), [forums](http://spreadcointalk.org/) and [website](http://www.spreadcoin.info/).

#Treasury

##Who paid for all of this?

Helium never did an ICO and we started off bankrupt. Costs like the Cryptopia listing were paid out of pocket by the founders and launch development and PR were all paid out of pocket or done pro bono by people in the community.

The aforementioned wallet that was kept out of the distribution, along with all <10 HLM balances on the ledger, were put into a multi signature address. [You can find it here](https://www.heliumchain.info/#/address/3JcEX7PQCSZW6i8Ye4iHfn3QFEKbAtNyVa). This is the treasury.

Part of the coins has already been spent to reimburse those that fronted the tens of thousands of dollars that were used to get us of the ground. [You can find an overview of treasury expenses here.](https://www.heliumlabs.org/docs/treasury-overview)

##What will happen to the rest of the coins?

The coins in the treasury address will be used to establish the Helium ecosystem and to help the project through the early phases. 

The treasury will act in concordance with the team and the community but it will act independently. The treasury will strive to be as transparent as possible. Every single Helium leaving the treasury address will be accounted for. 

The ultimate goal is, of course, to establish a self sustaining economic model by means of decentralized governance and governance subsidy (superblocks). Until then the treasury will ensure that all the basics are met with regards to the finances. 

## Who is in control of the coins?

The coins are held in a 2/3 multisig wallet. @KarmaWolf holds a key, @rhinomonkey holds a key and @teela holds a key. 

@KarmaWolf represents the founders and the team. @rhinomonkey was the third person to join the Helium Slack and has a long history within the SPR community. @teela was put forward and voted into office by the people in Slack. 

@RzeroD volunteered and was elected as first reserve for the treasury. 


# The Team

## Who are the HLM team?

Read a bit more about the HLM team on the [homepage.](https://heliumchain.org/team/)

## Who are the devs?

@gj (gjhiggins) did a formidable amount of work getting the snapshot up to spec, and made sure HLM launched in the first place. He did not leave without a lasting legacy of thought material and possible angles for future development. @richyjames took care of development on the launch phase with @gj, @faetos and several others.

We enlisted the help of the Phore team veterans to help us through the critical phase of launching the actual chain. They assisted with code, code review, consultancy and they launched the chain.

There are countless others who are making this possible by actively engaging and providing (development) work, resources and advice. The community hereby thanks itself.

In the meantime, Helium's most valuable asset is **you**. Decentralized means a couple of things and one of them is: if you want it, make it and if you make it its yours. So if you have something to add; drop by in #dev or hang around in #general and test the waters.

## What's the story with how Helium came to be?

@coins101 put it like this:

> I joined Spreadcoin in Feb 2015, after leaving DASH
> 
> just before Feb 2015, I spent several months trying to get the DASH lead dev to add services to DASH
> 
> he was focused only on competing with Bitcoin using only Instantx and coin mixing
> 
> I really wanted to go after services as Master nodes can do so much more than just coin mixing
> 
> I have been working on services for a second layer for a few years now, the first concept was to build accounts, so that people who knew zero about crypto could still use crypto the same way they use an online wallet service like Coinbase or PayPal
> 
> After I left, DASH investors liked that idea so much they got Evan to work on it - now called Evolution
> 
> We're building on that, but also adding some new dimensions associated with Smart Cities
> 
> The lead dev of Spreadcoin isn't a fan of Enterprise applications, so we've decided to part ways and so the work I and others have been doing for over 2 years will be moved into Helium

# Who writes the FAQ?

Currently this faq is written and maintained by @kristerv, @teela and you.


#Eternal Hall of Fame 
*(eternally under construction)*

**Youtube Man**

@AKcryptoGUY

**Bug Squatter**

@??????

**Listing Patrons:**

@stonehedge and @cryptoconsultant

**Fork Busters:**

@RzeroD, @Slacker, @knout, @spready, @unobt

**Block Explorers:**

@Cryptotron and @RzeroD

**Big Help:**

@xojex and @kyle

**DNS Seed Savior:**

@knout

**Helium Crowdfund Heroes:**

@allomancer_jak

@cryptoconsultant

@KarmaWolf

@overbuilt

@richyjames

**Snapshot MVP:**

@gjhiggins tied with @phire

**Mighty Mouse:**

@gj

**Awesome:**

@faetos

**Super Saiyan:**

@kristerv

**Regular Saiyan:**

@Moonshot

**the Omnipresent:**

@cryptosteve

**Bitcointalk top Ninja:**

@szfinx

**Tourney champions**: 

@rhinomonkey, Wielder of the Swarovski Crested Belly Putter, General der Flakartillerie.

@e1ghtspace, Master of the Purple Robot Unicorn. [Stringfellow Hawke](https://www.youtube.com/watch?v=l8syGlAMTKA)

@overbuilt, God Emperor of Dune.

**DISCLAIMER**: quotes in this faq are verbatim. They were pulled from Slack so interpunction, capitalization and paragraphing might be edited for the sake of readability. Also: this FAQ is community built, supported and maintained. So if you don't like it: go ahead and make your own FAQ with blackjack and hookers.