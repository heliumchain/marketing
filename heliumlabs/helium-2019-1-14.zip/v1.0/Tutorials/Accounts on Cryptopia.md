---
title: "Accounts on Cryptopia"
excerpt: ""
---
This is a video tutorial about how to create an account on Cryptopia

[block:api-header]
{
  "title": "1. Creating an account:"
}
[/block]

[block:embed]
{
  "html": "<iframe class=\"embedly-embed\" src=\"//cdn.embedly.com/widgets/media.html?src=https%3A%2F%2Fwww.youtube.com%2Fembed%2F22yLz7TgcWQ%3Ffeature%3Doembed&url=http%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3D22yLz7TgcWQ&image=https%3A%2F%2Fi.ytimg.com%2Fvi%2F22yLz7TgcWQ%2Fhqdefault.jpg&key=f2aa6fc3595946d0afc3d76cbbd25dc3&type=text%2Fhtml&schema=youtube\" width=\"854\" height=\"480\" scrolling=\"no\" frameborder=\"0\" allowfullscreen></iframe>",
  "url": "https://www.youtube.com/watch?v=22yLz7TgcWQ",
  "title": "Cryptopia Tutorial - Creating an Account",
  "favicon": "https://s.ytimg.com/yts/img/favicon-vfl8qSV2F.ico",
  "image": "https://i.ytimg.com/vi/22yLz7TgcWQ/hqdefault.jpg"
}
[/block]

[block:api-header]
{
  "title": "2. Trading:"
}
[/block]

[block:embed]
{
  "html": "<iframe class=\"embedly-embed\" src=\"//cdn.embedly.com/widgets/media.html?src=https%3A%2F%2Fwww.youtube.com%2Fembed%2FgeRz4vqCA4Q%3Ffeature%3Doembed&url=http%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3DgeRz4vqCA4Q&image=https%3A%2F%2Fi.ytimg.com%2Fvi%2FgeRz4vqCA4Q%2Fhqdefault.jpg&key=f2aa6fc3595946d0afc3d76cbbd25dc3&type=text%2Fhtml&schema=youtube\" width=\"854\" height=\"480\" scrolling=\"no\" frameborder=\"0\" allowfullscreen></iframe>",
  "url": "https://www.youtube.com/watch?v=geRz4vqCA4Q",
  "title": "Cryptopia Tutorial - Trading",
  "favicon": "https://s.ytimg.com/yts/img/favicon-vfl8qSV2F.ico",
  "image": "https://i.ytimg.com/vi/geRz4vqCA4Q/hqdefault.jpg"
}
[/block]

[block:api-header]
{
  "title": "3. Deposits and withdrawals:"
}
[/block]

[block:embed]
{
  "html": "<iframe class=\"embedly-embed\" src=\"//cdn.embedly.com/widgets/media.html?src=https%3A%2F%2Fwww.youtube.com%2Fembed%2FykWYQ5vZBh0%3Ffeature%3Doembed&url=http%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3DykWYQ5vZBh0&image=https%3A%2F%2Fi.ytimg.com%2Fvi%2FykWYQ5vZBh0%2Fhqdefault.jpg&key=02466f963b9b4bb8845a05b53d3235d7&type=text%2Fhtml&schema=youtube\" width=\"854\" height=\"480\" scrolling=\"no\" frameborder=\"0\" allowfullscreen></iframe>",
  "url": "https://www.youtube.com/watch?v=ykWYQ5vZBh0",
  "title": "Cryptopia Tutorial - Deposits and Withdrawals",
  "favicon": "https://s.ytimg.com/yts/img/favicon-vfl8qSV2F.ico",
  "image": "https://i.ytimg.com/vi/ykWYQ5vZBh0/hqdefault.jpg"
}
[/block]
NB: If something goes wrong and you need to contact Cryptopia support: bear in mind that there is a 2 week backlog in support tickets due to the immense amount of new users. Sit back and chill. They will get back to you. It just takes a while.