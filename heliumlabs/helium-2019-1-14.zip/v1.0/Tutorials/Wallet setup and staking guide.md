---
title: "Wallet setup and staking guide"
excerpt: ""
---
**By spready, parts of this guide were copied from PIVX.org**

#Wallet setup

##Installing

Download the latest stable wallet release from the github:

[https://github.com/heliumchain/helium/releases](https://github.com/heliumchain/helium/releases)

We're currently releasing our wallets through Github **only** so don't install things you find somewhere else.

Some antivirus programs (Avast being a common culprit) will give a false positive when trying to install the Helium wallet. You can run the files through an aggregated antivirus engine such as [VirusTotal](https://www.virustotal.com) to make sure they are safe.

##Encrypting

Run the Helium client and encrypt your wallet from the **settings** menu.

Encrypting your wallet is a great idea to prevent other people using your computer to steal your money or your wallet.dat file. Please don’t forget the encryption password. If you lose it, you can’t access your funds. 

##Backing up

Run the Helium client and backup your wallet from the **file** menu. Save a copy of the wallet.dat file in a secure location. Saving a copy on a different drive or an external solution (i.e. USB stick) saves you in case of drive failure. Unencrypted wallet.dat files are not secure if stolen.

The most important thing in cryptocurrencies is backing up your wallet data! Always keep backups in multiple places so your money is safe in case you lose access to the computer. Every time you create a new receiving address, you must backup your wallet.dat file or you risk losing your newly received funds.

A wallet.dat **can** go corrupted. A less convenient but even safer way is to back up your private keys. AKcryptoGuy made a youtube tutorial on that. [Find it here.](https://www.heliumlabs.org/v1.0/docs/how-to-export-and-backup-your-private-keys)

##Ready to use

Once your wallet is fully synchronized it is ready to use. Pressing request payment on the receiving tab will generate an address for receiving Helium. Fields on the receiving page are optional to fill.

**NEVER GIVE ANYONE YOUR PRIVATE KEYS.**

#Staking

##Get some Helium

Get some Helium from an exchange, your friendly Heliumite neighbor or claim your HLM from the airdrop. [You can read how to claim your airdrop coins here.](https://www.heliumlabs.org/docs/importing-a-spreadcoin-private-key)

Wait for your Helium to have 101 confirmations on the transactions tab.

##Unlock your wallet

Unlock your wallet from the **settings** menu. Make sure you select the **for anonymization, automint and staking only** checkbox so your funds aren’t spendable by anyone visiting your computer.

##Ready to stake

You’re already staking! Soon you will have a staking reward sent to you in your transactions list. If you aren’t receiving any rewards look at the bottom right corner on your client to make sure the second icon says “staking is active”. Rewards arrive at random intervals and the higher your balance, the more often they come.

##Optimize staking

Depending on the amount of coins you have, it can be advisable to split your coins into several smaller inputs. One of the reasons is that when you win a stake your input will go immature, and you won't be able to win another stake for 101 blocks. There is no real way to calculate the ideal number. So look at the blockexplorer to get an idea of the average size of wallets that are most often winning stakes or consult your local Voodoo priest.