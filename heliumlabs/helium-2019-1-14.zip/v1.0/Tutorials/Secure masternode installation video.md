---
title: "Secure masternode installation video"
excerpt: "Complete and security-focused version of the masternode install guide"
---
[block:callout]
{
  "type": "warning",
  "title": "We've added the NodeValet scripts that are a lot easier to use than Nodemaster and have extra functionality. Please find the links on the left side of this page."
}
[/block]
We have adapted the well-known Nodemaster install script for use with Helium. Nodemaster offers a relatively simple and automated way to set up one or more Masternodes on a single VPS (IPv6).

The link for the script is here (including a guide):

[https://github.com/heliumchain/vps](https://github.com/heliumchain/vps)

AKcryptoGUY made a video tutorial and accompanying text guide on installing multiple Masternodes with Nodemaster.  This is the original full version which employs several server hardening strategies in addition to the masternode deployment and is meant for those who want a fully-secured VPS hosting their masternodes.

[https://medium.com/@AKcryptoGUY/securely-install-multiple-helium-masternodes-3ee2e995a5e0](https://medium.com/@AKcryptoGUY/securely-install-multiple-helium-masternodes-3ee2e995a5e0) 

If you find his guide or video helpful, please consider supporting his contributions by using his referral link to create your Vultr hosting account: [https://www.vultr.com/?ref=7568060](https://https://www.vultr.com/?ref=7568060) 

[block:embed]
{
  "html": "<iframe class=\"embedly-embed\" src=\"//cdn.embedly.com/widgets/media.html?src=https%3A%2F%2Fwww.youtube.com%2Fembed%2Fmj1FyN6Wauk%3Ffeature%3Doembed&url=http%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3Dmj1FyN6Wauk&image=https%3A%2F%2Fi.ytimg.com%2Fvi%2Fmj1FyN6Wauk%2Fhqdefault.jpg&key=f2aa6fc3595946d0afc3d76cbbd25dc3&type=text%2Fhtml&schema=youtube\" width=\"854\" height=\"480\" scrolling=\"no\" frameborder=\"0\" allow=\"autoplay; fullscreen\" allowfullscreen=\"true\"></iframe>",
  "url": "https://www.youtube.com/watch?v=mj1FyN6Wauk&feature=youtu.be",
  "title": "Multiple Helium Masternod Setup on Vultr VPS",
  "favicon": "https://s.ytimg.com/yts/img/favicon-vfl8qSV2F.ico",
  "image": "https://i.ytimg.com/vi/mj1FyN6Wauk/hqdefault.jpg"
}
[/block]