---
title: "Masternodes with the One Master Script"
excerpt: ""
---
Below is the link to Helium's shiny and new Masternode installation script. It is an extended version of the Nodemaster script you've all been using before and adds a lot of ease of use and functionality. A detailed guide can be found on its github page. 

[https://github.com/akcryptoguy/one-master-script](https://github.com/akcryptoguy/one-master-script)