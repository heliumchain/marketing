---
title: "Masternode/wallet update guide"
excerpt: ""
---
The below is a guide on how to update your wallet and Masternode(s) in the event of a new wallet release. Depending on the update, this can be as easy just downloading the new wallet and running it. But there are some scenarios where it gets a tad more complicated. As with the current update for example.


<span style="color:red">Before you do **ANYTHING**. back up your **wallet.dat** (**File**>**Backup Wallet**) or better yet: make a copy of **wallet.dat** and put it somewhere safe.</span>

##**Local wallet (Windows/OSX/Linux)**


To update your local wallet browse to [www.github.com/heliumchain/helium/releases](www.github.com/heliumchain/helium/releases) and download the newest version for your system from the top of the page. There is no need to remove the old client from your system first, but you might want to in order to keep things tidy.

Some updates, such as v0.15.2, require you to resync your wallet. There are two ways to do this. 

**-From the data folder:**

When you first launched your wallet it created a data folder and, unless you specified a custom directory, you can find it here:

Win: <code>%Appdata%/Helium</code>
OSX: <code>~/Library/Application Support/Helium</code> or <code>~/.helium</code>
Linux: <code>/.helium</code>

By deleting everything in the folder <span style="color:red">**EXCEPT** </span><code>wallet.dat</code>, <code>helium.conf</code>, <code>masternode.conf</code> and the **backups** folder, and restarting the wallet you will force it to synchronize from scratch. It will take a while to sync and for your balance to appear.

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/3251de8-datadir.png",
        "datadir.png",
        480,
        700,
        "#f8e9e9"
      ]
    }
  ]
}
[/block]
**-From the wallet:**

You can also resync from the wallet. This is a bit less reliable however.
Open your Helium wallet, click **Tools** then **Wallet Repair** then **Delete local Blockchain Folders** and select **Yes**. This reboots the wallet and tells it to resync.

**-Notes**

If the above doesn't work at first at first, just try again.

Manually deleting files in the data folder sounds a bit hard core but it **always** does the trick, as opposed to the wallet method. 

##**Masternode, single instance, Ubuntu VPS**


Updating a masternode is a bit more complicated than updating your local wallet but not much. Assuming you have the same set up as described in the [Masternode setup guide](https://www.heliumlabs.org/v1.0/docs/masternode-setup-guide) you can follow the steps below.

After updating your local wallet, log in to your VPS and switch to the user with which you installed the Masternode: <code>su *USERNAME*</code> and <code>cd</code>

In order to update we will need to stop the Masternode first with:

<code>sudo helium-cli stop</code>

We'll then download the new binaries, unpack them and install them:

<code>wget https://github.com/heliumchain/helium/releases/download/v0.15.2/helium-0.15.2-x86_64-linux-gnu.tar.gz</code>
<code>tar zxvf helium-0.15.2-x86_64-linux-gnu.tar.gz</code>
<code>sudo cp -r ~/helium-0.15.2/bin/. /usr/local/bin/</code>

And we will start the new client and tell it to synchronise from scratch:

<code>sudo heliumd -daemon -resync</code>

After it is fully synced you can return to your local wallet, open the **Masternodes** tab and restart your Masternode.

In the event that starting the client with the -resync option doesn't achieve the desired result: you can also manually remove the blockchain data and force the client to resync. Stop your masternode first. Then:

<code>cd .helium && sudo rm -rf !(wallet.dat|helium.conf|masternode.conf)</code>

Restarting it with <code>sudo heliumd -daemon</code> will make the client sync from scratch.

##**Masternode, multiple instances, Nodemaster install script**


**1: Initial setup and usage **


Follow the detailed instructions posted here: https://github.com/trollboxteela/vps

**2: Updating Nodemaster masternodes:**

Repeat for each node, stop node:
<code>sudo systemctl disable helium_n1</code>
<code>sudo /usr/local/bin/helium-cli -conf=/etc/masternodes/helium_n1.conf stop</code>
<code>sudo systemctl stop helium_n1</code>

Now remove the old version of the VPS script and the compiled binaries.

If you installed as <code>root</code> user (otherwise replace /root/ with the home directory of the user with which you installed the nodes):

<code>rm -rf /root/vps</code>
<code>rm -rf /root/.helium</code>

Next, run the script with the "-u" parameter to upgrade existing nodes.

In /root:
<code>git clone https://github.com/trollboxteela/vps.git && cd vps && ./install.sh -p helium -u</code>

This method pulls the latest sources from https://github.com/heliumchain/helium

When your nodes are on the wrong chain and a normal resync won't stick past reboot, delete all blockchain data for each node.

Repeat for each node (optional step, in case your nodes are on the wrong chain):
<code>cd /var/lib/masternodes/helium1 && rm -rf !(wallet.dat|masternode.conf)</code>

Finally repeat for each node, start node:
<code>sudo systemctl enable helium_n1</code>
<code>sudo systemctl start helium_n1</code>

You can track status via
<code>/usr/local/bin/helium-cli -conf=/etc/masternodes/helium_n1.conf getinfo</code>