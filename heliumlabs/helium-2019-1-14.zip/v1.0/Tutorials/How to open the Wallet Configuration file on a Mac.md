---
title: "How to open the Wallet Configuration file on a Mac"
excerpt: ""
---
**This guide was copied from pivx.freshdesk.com**

MacOS has no default program association with the .conf file type; this prevents the Helium wallet from opening the Wallet Configuration file (or **helium.conf**) from the **Tools** dropdown menu.

To navigate to the configuration file from the desktop:

>-Open a finder window, 
>-Select the **Go** dropdown menu. 
>-In this menu please press the **Go to Folder...** option. 
>-In the window that opens type: <code>~/Library/Application Support/Helium</code> and press enter. 
>-if the folder cannot be found please repeat the steps and enter: <code>~/.helium</code>

If the folder still cannot be found:

>-Open the wallet and select the **Tools** drop down menu.
>-Select the **Wallet Repair** option.
>-Make note of the folder which contains the wallet in use.
>-Use the specified folder in the **Go to Folder...** option.
>-Double click on **helium.conf**.
>-A popup window will state that <code>There is no application set to open the document “helium.conf"</code>. Press the **Choose Application...** button.
>-Now in the window that opens scroll down to select the **TextEdit** application and select **open**.
>-Enter your configuration updates.
>-Click the **File** menu and select **save**.
>-Click the **File** menu and select **close**.
>-Restart the wallet for the configuration to take effect.

To navigate to the configuration file from within the Helium wallet:

>-Open the Helium wallet
>-Click the **Tools** menu and select **Show Automatic Backups.**This will open a finder window with a bunch of **wallet.dat** files in it.
>-Click this finder window and press the **cmd** key along with the **up arrow** at the same time. This will cause your finder window to move up one directory into the Helium data directory.
>-Double click on helium.conf
>-A popup window will state that <code>There is no application set to open the document “helium.conf”</code>. Press the **Choose Application...** button
>-Now in the window that opens scroll down to select the **TextEdit** application and select **open**.
>-Enter your configuration updates.
>-Click the **File** menu and select **save**.
>-Click the **File** menu and select **close**.
>-Restart the wallet for the configuration to take effect.

To navigate to the configuration file from the Terminal:

>-Open the terminal by using Spotlight search in OS X, searching for “terminal”
>-Determine your user name by entering:
><code>id -un</code>


>-Enter the following where <code>username</code> is replaced with the output from line 2: 

>High Sierra: 

><code>open -a TextEdit /Users/<username>/.helium/helium.conf</code>

>Other: 

><code>open -a TextEdit /Users/<username>/Library/Application Support/Helium/helium.conf</code>

>-Enter your configuration updates.
>-Click the **file** menu and select **save**.
>-Click the **file** menu and select **close**.