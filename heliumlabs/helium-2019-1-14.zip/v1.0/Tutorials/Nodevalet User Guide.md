---
title: "Nodevalet User Guide"
excerpt: ""
---
**Shell commands**

Just because you won't have to log in to your VPS doesn't mean you can't :). To keep things easy NodeValet uses Nodemaster to configure the actual Masternodes so everything is exactly where you'd expect it to be. In addition NodeValet keeps its files in  `/var/tmp/nodevalet` and its logs in `/var/tmp/nodevalet/logs`

We've added a few small scripts to make the most common commands a lot easier. You can just enter these on the command line:

`checksync`  will return the syncing status of all masternodes.
`autoupdate`  will run the autoupdate script and check for a new version. (rather than wait for the scheduled check)
`checkdaemon`  will check if all masternodes are correctly synced.
`makerun`  checks if all installed masternodes are running.
`rebootq`  checks if recent system updates require a reboot. (rather than wait for the scheduled check)
`getinfo 1`  returns a summarized `getinfo` of masternode 1, 2, 3 etc. `getinfo` shows all.
`killswitch`  turns off all masternodes. Use `activate_masternodes_COIN` to turn them back on.
`masternodestatus 1`  returns the `masternodestatus` of masternode 1,2,3 etc. `masternodestatus` returns all. 
`resync 1`  deletes blockchain data for node 1, 2, 3, etc and forces a resync.
`showlog`  displays the installation log
`showmlog`  displays the maintenance log