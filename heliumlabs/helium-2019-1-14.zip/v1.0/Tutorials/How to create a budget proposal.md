---
title: "How to create a budget proposal"
excerpt: ""
---
**Under construction**

Below is a guide on how to create and submit a budget proposal to the Helium network. This guide is under construction and will be improved upon as we go. You can read more about our governance and budget system [here](https://www.heliumlabs.org/v1.0/docs/governance-overview). You can read more about what to do before submitting an actual proposal here (LINK TBA).

In short: Helium has a 7.2% governance budget that is paid out once a month (every 43200 blocks) in so called Superblocks. The total of the budget is a maximum of 15552 HLM, 7.2% of the total block rewards for that period. Any user can submit a proposal for a one time fee of 50 HLM.  

For a proposal to be funded it needs a total of 10% of all masternodes voting Yes on it, after subtracting all No votes. Voting is cut off at 2880 blocks before the Superblock. Note that your proposal needs to be in the system and available for voting for a minimum of 24 hours. This means that the cut off for submitting proposals is 3 days before the Superblock.

Submitting a proposal is done through the debug console or the command line in two steps. One that prepares the proposal and one that submits it. Your wallet needs to be unlocked and needs a balance of at least 50 HLM to cover the fee.

##Step 1: Creating the proposal.

Below is a sample of what the command for an actual proposal looks like:

```preparebudget "Awesome Project" "https://tinyurl.com/y9f9gfo" 1 86400 "SZBnTFogAq5WhoCFZpYrBCPpBLgBrTUGhA" 500```

As you can see there are a couple of things to fill in. We will break it down below.

- `preparebudget` - This is the console command.
- `"Awesome Project"` -This is the title of the proposal (keep it concise)
- `"https://tinyurl.com/y9f9gfo"` - This is a URL that links to a description of your proposal. There is a maximum amount of characters here so use a URL shortener. [The Helium forums](https://heliumcha.in/c/budget-governance-proposals) are a great place to present and discuss your proposal.
- `1` - This is the frequency of the payment. This proposal will only be paid out once.
- `86400` This is the block number of the next Superblock. You can find the block number of the next Superblock by entering `getnextsuperblock` in the console.
- `"SZBnTFogAq5WhoCFZpYrBCPpBLgBrTUGhA"` - This is the address that will receive the coins.
- `500` - This is the amount in HLM that will be received. 

So: `preparebudget` <name of proposal> <info link> <how many payments> < starting block> <payment address> <payment amount>

Pressing enter will return the preparebudget hash that looks like this:

`92304436a29dd29a83cd5fbea8ae1c220d295af32f41a552gvf9769fe1e24bb9`

We will use it in the next step. So don't lose it! If you do lose it you will have to pay the 50 HLM fee again.

**Please note that if you submit a proposal with multiple payments in multiple budget cycles, every installment can and will be voted upon.** 

##Step 2: Submitting the proposal. 

After the fee has been paid and 6 confirmations we're now ready to submit the proposal. We use a similar command with the preparebudget hash at the end:

```submitbudget "Awesome Project" "https://tinyurl.com/y9f9gfo" 1 86400 "SZBnTFogAq5WhoCFZpYrBCPpBLgBrTUGhA" 500 92304436a29dd29a83cd5fbea8ae1c220d295af32f41a552gvf9769fe1e24bb9```

Pressing enter will submit your proposal to the network and return the final proposal hash which looks like this:

```86195f3f894433b04be7823d02e9a5dce843b49675ecea109dbfb43405da3aa1```
 
This is the hash that will allow other masternodes to vote for your proposal. You can always retrieve it with `mnbudget show`

Your proposal has now been added to the budget and will be open for voting until voting until the budget has been finalized. For more information please see the [Governance Overview](https://www.heliumlabs.org/v1.0/docs/governance-overview).

**NOTES**

There is one more thing that needs to happen before the budget can be paid out. 
Voting cuts off 2880 blocks before the Superblock. And during those 2880 blocks the budget needs to be finalized. This is a step that only needs to be done by 1 person on the network. It doesn't matter who does it as long as **someone** does it. When no one does it the budget will not be paid out.

To finalize the budget during the 2880 blocks before the Superblock: Your wallet should only have a single input. Easiest is to send your entire balance to yourself on a single address. Close the wallet and open your `helium.conf` file. Add a line in there with `budgetvotemode=suggest` and restart the wallet. After you unlock the wallet it will automatically send a 5 HLM transaction that finalizes the budget and makes sure the budget is paid out. Once the transaction has 1 confirmation you can close the wallet and remove the line from `helium.conf`.