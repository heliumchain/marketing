---
title: "Getting Started with Heliumlabs"
excerpt: ""
---
**Hi! So you've found us and now you need to figure out what is what?!**

Heliumlabs is a community initiative that aims to collect and sort all important information regarding the Helium project in one place. Right now its not much to look at, but as time progresses things will get added so please bear with us.

If you have a project you feel will provide value to the Helium network; you can apply for a free heliumlabs.org subdomain. Ask around in the discord and someone will sort you out.

The FAQ is updated regularly so whatever you want to know is probably in there.

If you can't find the answer to your question please drop it in Q&A

You are always welcome to join us on discord:

https://discord.gg/PzFjPBy

You are free to use/copy/adapt any content of this website. A mention is always appreciated but by all means take what ever you need, as long as it is for a good cause.

***Disclaimer:***

1 This is a community initiative so please bear with us.
2 We try to gather everything important and put it here.
3 We try to keep the information on here as up to date as possible.
4 This is community supported so if you think it's all bullocks you can comment and make it better.