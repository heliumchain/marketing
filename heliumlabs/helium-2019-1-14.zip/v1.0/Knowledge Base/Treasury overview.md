---
title: "Treasury overview"
excerpt: ""
---
The Treasury is not be confused with our Governance system. You can read more about the Treasury in the [FAQ](https://www.heliumlabs.org/v1.0/docs/frequently-asked-questions#section-treasury).

The Treasury address is here:
https://www.heliumchain.info/#/address/3JcEX7PQCSZW6i8Ye4iHfn3QFEKbAtNyVa

Below you will find an overview of the launch costs as well as the monthly expense reports. 
<br>

- [Treasury expenses month 3](https://www.scribd.com/document/396972633/Expenses-Month3)

- [Treasury expenses month 2](https://www.scribd.com/document/395952987/Expenses-Month-2)

- [Treasury expenses month 1](https://www.scribd.com/document/392774865/Helium-Expenses-Month-1)

- [Overview of Helium launch costs](https://www.scribd.com/document/390562465/Helium-Launch-Costs) 

The Helium Treasury works to have everything as transparent and open as possible. Every payment you see in the above reports was discussed in public. To make sure everything is transparent we keep a record of all conversation in the Slack. It takes some effort but you will find everything here: https://slarck.com/v2d0Ku/

@teela is the spokesperson of the treasury. Don't hesitate to send a message.

We realize that having things on a 1 page PDF (in the hope that people actually read it) some of the context is lost. Below are the answers to some of the obvious questions.

##A lot of people got coins for 'development funding'. What was that?

As you all know Helium wasn't doing too well in winter this year. Some community members pooled together ~20000 dollars to get development back on track. The Treasury paid this back.

The fundraiser was conducted in the #devpayments channel in Slack and you will find it in the archives.

Some of those people offered to settle the loans at 1$/HLM. Some agreed to take back HLM at spot price after launch, some were paid back dollar value in BTC. 

##There are some payments in the Launch Cost overview that I can't find in the Slack?

When the community decided to take over the Helium project from coins101 somewhere in February @richyjames offered to spearhead the operation. 

The community gave @richyjames Carte Blanche to do whatever was necessary to get the project back on track. @richyjames did just that and in the process the network incurred some costs which were paid by the Treasury as soon as the network went live.

Helium owes a large part of its existence to @richyjames. Meanwhile @richyjames never asked a single satoshi for his efforts.

##Why is the Treasury paying teela and stonehedge?

The decision to have a Treasury fund in the first place was made to ensure that the network has a strategic reserve. The plan is to go fully DAO in the future and the Treasury is there to ensure that happens.

Teela was hired because a DAO is all nice and well but you do need a person who makes sure things are taken care of. Amongst others, teela works to ensure necessary information is readily available, ensures communication between the team and the broader community and takes care of a host of other (small) things that are part of the day to day operations of the project.

Teela recieves 2000 EUR + 2000HLM a month for his efforts.

The treasury hired Stonehedge at a market rate of 10 BTC and 60000 HLM for the coming year. There was a lengthy discussion between the Treasury and people involved in the project but in the end we decided to cough it up because he is worth it.

Stonehedge brings a lot of relevant business experience and has years of experience in crypto. Amongst others, he helped to bring Crown from nothing to a multi million blockchain. Stonehedge has the contacts and the know-how to bring Helium towards real world applications. He'll be supervising development and Enterprise efforts.

##What's the nature of the transactions made to KarmaWolf?

Apart from the investment in personal time Karma also spent a lot of cash in getting Helium back on its feet. As you can see from the overview a large amount of HLM went his way.

Karma was paid 40k HLM for taking on the responsibility for the project:
https://medium.com/@jasonmcassidy/helium-pre-launch-update-853a6d161382

Karma was also refunded for the Cryptopia listing fee of 5 BTC that was paid in 2017.

On top of this. Karma purchased 10.75 BTC worth of Helium from the Treasury at a rate of 1$/1HLM (BTC spot price). The 10 BTC was needed by the treasury to make sure it could cover Stonehedge's salary without having to place a big bet (and burden) on the open market. The remaining 0.75 BTC was used to repay cryptosteve for a 5000$ loan  he made during the crowdfunding round. 

Karma effectively took >100k USD off of the shoulders of the network and allowed us to start with a clean slate. The treasury thanks him for making our lives easier.