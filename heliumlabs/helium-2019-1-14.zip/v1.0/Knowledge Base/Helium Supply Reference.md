---
title: "Helium Supply Reference"
excerpt: ""
---
Below is a print of a spreadsheat showing coin supply and emission rate over time.
[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/baeabb3-HLM_supply_reference_1.png",
        "HLM supply reference_1.png",
        1169,
        826,
        "#92ebca"
      ]
    }
  ]
}
[/block]

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/36cd31b-HLM_supply_reference_2.png",
        "HLM supply reference_2.png",
        1169,
        826,
        "#94f1dd"
      ]
    }
  ]
}
[/block]

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/fdea69e-HLM_supply_reference_3.png",
        "HLM supply reference_3.png",
        1169,
        826,
        "#d9f569"
      ]
    }
  ]
}
[/block]

[block:image]
{
  "images": [
    {
      "image": [
        "https://files.readme.io/f50501d-HLM_supply_reference_4.png",
        "HLM supply reference_4.png",
        1169,
        826,
        "#f0f9cf"
      ]
    }
  ]
}
[/block]